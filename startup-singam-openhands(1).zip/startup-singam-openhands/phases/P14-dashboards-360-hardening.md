# P14 – Dashboards, 360 views, seed and hardening

**Goal:** complete every dashboard and metric, the Startup 360 and Investor 360 views, the Management dashboard, a full-season seed, the complete cross-persona e2e suite, and a security, accessibility and performance pass.

**Depends on:** all previous phases.
**Read first:** `docs/11` §11.6–11.7; `docs/12` (all); `docs/13` (all); `docs/08`; `docs/09` §9.9.

## Scope

### Dashboards
- Implement every tile in `12` for SR (My startups, Team view), IR (My investors, Team view), Finance, Production (My shoots, Production view), Legal, Marketing, Community, Analyst, Management. Every tile drills into the filtered list. Season / owner / date filters. Metrics as SQL views; heavy ones as materialised views refreshed by events.
- Workload metrics per RM / IRM / coordinator; stage ageing; bottlenecks (stages with highest median age).

### 360 views
- Startup 360 and Investor 360 exactly as described in `11` §11.6, permission-filtered per viewer (Production/Marketing/Analyst variants).
- "Waiting on" indicator on every record.

### Global search
- Startups, investors, persons; respects scope and redaction.

### Seed
- `pnpm db:seed:season` creates a realistic season: 60 applications across every stage, 20 investors across every stage, 3 episodes, deals in every closure stage, tranches incl. a reversal, fees in every status.

### Hardening
- Full e2e suite S01–S35 green.
- Security: OWASP ASVS L2 checklist pass on auth, sessions, access control, file handling; dependency audit; permission fuzz test S35 across all endpoints; rate limits.
- Accessibility: axe checks on every route; keyboard walkthrough of founder journey.
- Performance: load test (k6) of action queues and dashboards with seed ×10.
- Observability: structured logs, health checks, metrics endpoint, error tracking hook.
- Ops docs: `docs/RUNBOOK.md` (deploy, backups, restore, rotating secrets, replacing adapters with real providers).

## Acceptance
- All scenarios in `docs/13` pass; dashboards match hand-computed values on the seed (snapshot tests); no a11y violations of serious/critical level; p95 targets met.

## Prompt to paste

```
Finish the Startup Singam build with phase P14. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P14-dashboards-360-hardening.md. Complete every dashboard and metric in /spec/docs/12 with drill-downs, the Startup 360 and Investor 360 views with per-viewer filtering, global search, the full-season seed, and the hardening work (security, accessibility, performance, observability, runbook). Make the full acceptance suite S01–S35 in /spec/docs/13 pass. Report any metric or scenario you could not satisfy and why, and record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
