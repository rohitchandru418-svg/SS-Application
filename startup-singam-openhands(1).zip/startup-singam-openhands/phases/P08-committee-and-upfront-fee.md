# P08 – Final Shortlisting Committee and upfront fee

**Goal:** IR compiles the committee pack and records the decision; on Proceed the system automatically creates the upfront fee request (15-day clock), notifies Production and informs SR; Finance verifies turnover, applies the fee schedule, invoices (Zoho Books), and verifies payment against the bank before it is Paid.

**Depends on:** P07.
**Read first:** `docs/02` stages 10–11; `docs/03` stage 9; `docs/04` §4.1 step 8, §4.3 B, §4.5 steps 9–10; `docs/05` §5.2 H10–H12; `docs/06` CommitteePack, CommitteeDecision, fees; `docs/07` Committee, Upfront fee, Handover; `docs/08` approvals routing; `docs/09` automatic effects; `docs/12` Finance Upfront fee, Receipts, SR Upfront fee, Committee.

## Scope

### Committee
- Pack builder (IRM): auto-collects evaluation (analyst summary), IRR (approved version), investor feedback (verdicts, minutes), Golden Passes, unresolved questions, proposed investor participation, production readiness (placeholder text until P09), commercial status; editable summary; export to view-only PDF for committee members (A-09).
- Record decision: Proceed / On hold / Rejected, conditions, approvers (committee persons), decision date, re-review date, internal reason (never external).
- Founder: Final selection screen (labels from `02`). Investor: Committee results for startups they showed interest in (any pairing that reached Pitch Day or gave Ready/Next stage – A-79).

### Automatic triggers on Proceed (no manual step)
- Create `UpfrontFee` (`REQUESTED`, clock 15 calendar days from decision date).
- Production advance notice (`ProductionRecord` with `advanceNoticeAt`; planning list in P09 – create the record now and a notification).
- Inform SR (RM notification + lifecycle view).

### Finance – upfront fee desk
- Verify turnover: FY, turnover, evidence upload.
- Calculate: apply `UPFRONT_FEE_SCHEDULE` version from the season; show workings; exceptions (split payment, discount, other) with reason.
- Approve: standard → Finance lead; exception/discount → super admin (`Approval(FEE_EXCEPTION/FEE_DISCOUNT)`).
- Invoice: number, GST, due date, bank details; Zoho Books sync via adapter (status + retry; failures on dashboard).
- Follow up with SR: late reason, Management decision.
- Extensions: founder request or Finance-initiated; ≤ 7 days → Finance lead, > 7 days → super admin; new due date, original kept; ageing from original.
- Receipts to check: proof vs invoice vs bank line side-by-side; allocate receipt; part payments; reject proof with reason. A proof upload alone never sets Paid.
- Waivers, refunds, disputes → super admin approvals.

### Founder portal
- Upfront fee screen per `02` stage 11: amount, FY + turnover basis, invoice download, bank details, 15-day countdown, statuses, proof upload, extension request with reason.

### SR console
- Upfront fee follow-up (view + notes + chase), "% collected of fee determined, not collected, overdue".

### Automation
- Overdue transitions, reminder cadence, ageing buckets.
- `fee.upfront.fully_verified` → assemble handover pack (P09 builds the UI; in this phase create the `HandoverPack` with snapshot contents and `ASSEMBLED`).

## Acceptance
- S16, S17, S18, S19; S20 up to pack assembly.

## Prompt to paste

```
Continue the Startup Singam build with phase P08. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P08-committee-and-upfront-fee.md. Implement the committee pack and decision recording, the three automatic triggers on Proceed as event consumers (no manual step), the full Finance upfront fee desk with approvals, extensions, Zoho Books adapter sync and bank-verified receipts, the founder upfront fee screen and the SR follow-up view. A payment proof must never mark an invoice paid on its own. Store money as integer paise. Cover S16–S19 and the S20 assembly step with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
