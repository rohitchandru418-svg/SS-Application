# P01 – Super admin: seasons, policies, templates, users, approvals, escalations, reassignment

**Goal:** everything Management needs to set up a season and govern it, and the generic approvals / escalation / reassignment machinery every later phase uses.

**Depends on:** P00.
**Read first:** `docs/04` §4.4 (templates), §4.9; `docs/06` (Season and policy, Approval, Escalation, Assignment); `docs/07` (Approval); `docs/08` (Approvals routing); `docs/10`; `docs/11` §11.6 (Super admin); `docs/12` (Management – tiles only as placeholders until data exists).

## Scope

### Seasons and episodes
- `Season` CRUD with status machine `DRAFT → OPEN → CLOSED → ARCHIVED`. Opening requires: application window set, fee schedule policy version selected, at least one episode, committee members set, all required legal templates approved (founder MoU, participation agreement, NDA, ICL, SDAL, term sheet). Show a **season readiness checklist** that lists unmet items with links.
- Closing the window triggers `season.window_closed` (P02 uses it to expire drafts).
- `Episode` CRUD under a season.
- Committee members (expert panel) as `Person` records with role on the season.

### Policies (versioned, effective dates)
- Generic policy editor with one Zod schema per type: `SCREENING_PASS_MARK` (nullable number – "no pass mark yet"), `SCREENING_CRITERIA` (criteria list summing to 100 – A-67), `ANALYST_CRITERIA` (the five dimensions with scale – A-68), `INVESTOR_ELIGIBILITY` (rule list: field, operator, value – A-69), `GRADING_DIMENSIONS` (A-70), `UPFRONT_FEE_SCHEDULE` (turnover bands → fee, GST flag – A-29), `SUCCESS_FEE_DEFAULTS` (percent/fixed/slab, cap, upfront adjustment allowed, partner share off), `MATCHING_WEIGHTS`, `REMINDER_CADENCE`, `WORKING_DAY_CALENDAR`.
- New version requires effective date ≥ today; previous version auto-closes. History list with diff.

### Templates
- `Template` / `TemplateVersion` upload by Legal; submit for approval → `Approval(TEMPLATE_VERSION)` → super admin approves → `APPROVED`; only approved versions selectable.

### Users and roles
- Super admin: add internal users, assign roles and departments, deactivate (removes scope, keeps history).

### Approvals inbox (generic)
- `Approval` service: `requestApproval(type, subject, raisedBy, payload)` computes `dueAt = +2 working days` and approver role from the routing table in `08`. Inbox lists all pending for the viewer's approver roles, sorted by due, overdue first; approve / reject with reason; decision emits `approval.decided` with type so the owning module reacts. Any super admin can decide; decider recorded.
- Finance lead and Production head see their own approval types in the same inbox component.

### Escalations
- `Escalation` service: `raise(type, subject, cause, target)`, list, decide (record decision on the subject's history), close.

### Reassignment
- Tool: pick subject type (startup, investor, deal, production record), from-user, to-user, reason; bulk select; history kept in `Assignment`. Emits `assignment.changed` → realtime invalidation of both users' queues and the external portal (new contact name).

### Management dashboard skeleton
- Tiles from `12` § Management wired to empty-safe queries (0 until later phases populate). Approvals waiting & ageing tile works now.

## Acceptance
- Season cannot open until readiness checklist is green.
- Policy version effective-date rules enforced; a record evaluated under v1 keeps v1 after v2 goes live (unit test with a dummy evaluator).
- Approvals: S34. A template version cannot be used until approved.
- Reassignment: S33 (founder-side part completes in P02).

## Prompt to paste

```
Continue the Startup Singam build. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P01-admin-seasons-policies-approvals.md, plus the code from P00. Implement the P01 Scope in API, worker and the internal console (super admin, Legal templates, Finance lead/Production head approval views). Approvals, escalations and reassignment must be generic services that later phases call; follow the approval routing table in /spec/docs/08 exactly. Use the existing command, audit, outbox, realtime and permission helpers. Add tests for every rule in Acceptance, update the seed with an OPEN season (window, fee schedule v1 placeholder, 3 episodes, committee, approved templates), run all tests and fix failures. Record new assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
