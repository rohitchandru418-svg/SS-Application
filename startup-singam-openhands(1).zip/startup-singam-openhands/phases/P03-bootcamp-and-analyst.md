# P03 – Pre-bootcamp and analyst fit check

**Goal:** SR runs batch bootcamps until each founder's preparation is complete, then sends the startup to the analyst pool; analysts evaluate on redacted data and submit a recommendation; SR reviews it.

**Depends on:** P02.
**Read first:** `docs/02` stages 4–5; `docs/04` §4.1 steps 3–5, §4.2; `docs/06` BootcampBatch, BootcampParticipation, ActionItem, AnalystReferral, AnalystEvaluation; `docs/07` Application, Bootcamp, Analyst referral; `docs/08` Analyst redaction + `SCORE_ANALYST`; `docs/12` SR Bootcamp/Analyst, Analyst.

## Scope

### SR console
- Bootcamp batches: create batch with sessions (date, time, type: process briefing, readiness session, MoU & upfront fee briefing, Q&A), add Proceed startups (bulk), send invites (bulk), mark attendance per session (bulk grid), record briefings done and founder questions answered, assign action items (title, due, needs upload?).
- "Mark preparation complete" enabled only when all briefings recorded and required action items done (attendance alone is not enough).
- "Send to analyst" on prepared startups.
- Analyst decision review: recommendation, reason, outstanding concern; buttons depend on recommendation: Proceed/Conditional → "Continue to MoU" (P04 creates the MoU; in this phase just transitions to `MOU` state and creates the SR condition task for Conditional); Hold/Reject → no override action exists.

### Founder portal
- Bootcamp: accept/decline invite, sessions with dates, action items as `RequestItem`s/checklist.
- Investment fit check: "In progress" → "Fit check done" (or mapped Hold/Reject labels, A-15).

### Analyst console
- Single queue (assigned, due date, overdue). Evaluation workspace: **redacted** application, redacted documents, bootcamp outputs; scoring on the five dimensions (scale from `ANALYST_CRITERIA` policy), willingness to invest, indicative amount (labelled "Not a commitment"), recommendation, reason, outstanding concern, condition text for Conditional proceed. "Ask the founder (via SR)" composer → creates an SR task; SR posts it to the founder as a `RequestItem`; the answer and documents come back to the analyst redacted.
- Analyst cannot see any contact field or message the founder.

### Redaction service
- Implement `packages/domain/redaction`: field-level stripping, free-text PII replacement, PDF redacted variants with low-confidence review flag (A-55). Apply to every analyst-reachable endpoint and export.

### Automation
- Pool assignment (least loaded active analyst), 5-working-day due, overdue escalation (A-27).
- `analyst.evaluation.submitted` → notify RM, update founder label, create blocking SR task if Conditional.

## Acceptance
- S05, S06, S07.
- Redaction test: seed founder names/emails/phones into application text and a PDF; assert absence in every analyst response and file.
- Analyst indicative amount never appears in any investor meter or commitment metric.

## Prompt to paste

```
Continue the Startup Singam build with phase P03. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P03-bootcamp-and-analyst.md. Implement the SR bootcamp and analyst-review screens, the founder bootcamp and fit-check screens, the analyst console and the redaction service exactly as specified. Redaction must be enforced on the server for API responses, exports and files; write the redaction leak tests described in Acceptance. SR must have no way to override an analyst Reject. Cover scenarios S05–S07 with Playwright (multi-context, live updates), extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
