# P09 – Production and show operations

**Goal:** Production plans from the advance notice, accepts the IR-approved handover pack after full payment, runs the AV shoot, allocates episodes with IR (who builds the panel and runs pre-shoot confirmation with the 2-week IRR rule), prepares documents per signing event, runs the mock shoot (super admin approves readiness) and captures the main shoot on set, including exceptions, until deals are confirmed and the shoot file is complete; then editing and approval.

**Depends on:** P08.
**Read first:** `docs/02` stages 12–14; `docs/03` stages 10–11; `docs/04` §4.5 steps 11–12, §4.6; `docs/05` H12–H15, H19; `docs/06` Production and show; `docs/07` Handover pack, Shoots; `docs/08` `PERMITTED_BUSINESS`, `CONFIDENTIAL_DEAL`; `docs/12` Production.

## Scope

### Production console
- Planning list (advance notices, fee not yet paid): likely episode, rough schedule; no booking allowed.
- Handover packs: view snapshot (permitted info only), IRM approval step (IR console), Production accept → AV bookable.
- AV planner: story research notes, location, crew, schedule, founder availability request, shot requirements; mark complete; asset links.
- Episode allocation calendar (with IR): startup → episode + shoot date; Production head approves.
- Signing events: define per event (investor commits on set → ICL; founder accepts deal → SDAL; others) with required template type and deadline; documents prepared before mock.
- Mock shoot: readiness checklist (costumes & props, pitch revisions, demo readiness, stage movement & rehearsal, final ask & valuation, open actions; owner founder/internal); submit readiness → super admin approval.
- On-set capture (tablet-friendly; offline-tolerant queue – A-62): founder & investor attendance, live ask and offers per investor, accepted terms, lead/co-investor allocation, conditions, ICL and SDAL status, signatures done/outstanding, exceptions (five types with their follow-ups).
- Post-shoot documentation: collect outstanding signatures (paper → upload) by the deadline (A-14); shoot file complete.
- Editing & approvals: editing status, Production head review, super admin approval (A-30) → `episode.approved`.
- **My shoots** and **Production view** dashboards.

### IR console
- Approve handover pack.
- Pre-shoot panel builder: per episode, choose panel investors (grade and sector fit visible to IR only), record written proposed commitment, valuation boundaries, decision parameters, production briefing sent / acknowledged, outstanding issues and documents; IRR-received status per panel investor.
- 2-week rule: at T−14 days for each panel investor without IRR viewed/received → alert + compliance metric.
- Oversight view of main shoot capture.

### Founder portal
- AV: date, location, prep list, confirm availability. Mock: readiness checklist items they own. Main shoot: accepted offers, lead/co-investors, conditions, documents signed/outstanding, SDAL upload.

### Investor portal
- Pre-shoot confirmation: episode, shoot date, IRR received, proposed commitment, valuation boundaries, decision parameters, briefing (acknowledge), documents needed, "Confirm commitment in writing". Main shoot: offers, accepted deal, split, conditions, ICL (upload if they hold the signed copy).

### Automation
- `mainshoot.deal_confirmed` creates one `Deal` per accepted investor (P10 builds the deal room; create records and notify now).
- Exceptions: founder no-show → reschedule + SR informed; investor absent → panel adjusted + IR informed; deal withdrawn → reason + replacement search flag; signature refused → escalation to IR + super admin; technical failure → reshoot.

### Visibility
- Production never receives confidential investor remarks, deal documents, DD content, grade, analyst outputs (projector tests).

## Acceptance
- S20 (complete), S21, S22. Production projector leak test.

## Prompt to paste

```
Continue the Startup Singam build with phase P09. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P09-production-and-shoots.md. Implement the Production console (planning list, handover acceptance, AV, episode allocation, signing events, mock readiness with super admin approval, on-set capture with exceptions, post-shoot signatures, editing approval, dashboards), the IR handover approval and pre-shoot panel builder with the 2-week IRR alert, and the founder and investor shoot screens. Documents are driven by signing events, not file names. On deal confirmation create one Deal per accepted investor. Production must never see confidential deal data. Cover S20–S22 with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
