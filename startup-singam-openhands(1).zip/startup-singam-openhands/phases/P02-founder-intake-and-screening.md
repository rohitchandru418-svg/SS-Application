# P02 – Founder registration, profile, application, intake and screening

**Goal:** founders can register, build a reusable profile, draft and submit an application; SR receives it, auto-assigns an RM, detects repeat applicants and screens it on the 100-mark card with the information-required loop.

**Depends on:** P01.
**Read first:** `docs/02` stages 0–3; `docs/04` §4.1 steps 1–2 and SR dashboards; `docs/05` §5.3–5.4 rows for these steps; `docs/06` Startup side (Startup, Founder, StartupDocument, Application, ScreeningScorecard, InfoRequest); `docs/07` Application + Screening verdict; `docs/08`; `docs/10`; `docs/11` §11.3–11.4, SR screens; `docs/12` SR (Intake, Screening, Workload).

## Scope

### Founder portal
- Registration (OTP), one founder login per startup (A-05): registering with an email/phone already attached to a startup routes to login instead.
- Profile: company, founders (co-founders as records, no login), sector, stage, geography, financials per FY (hidden for Idea stage), documents. Reused across seasons.
- Application: section form (fields from the season's application form config – A-71), autosave, completeness % with missing-item list (each links to the field), Idea-stage skips financials, "Applications close in X days", submit at 100% with confirmation. On season close, drafts → `EXPIRED`.
- After submit: acknowledgement screen, RM name, read-only application.
- Internal review stage: verdict label only; for Information required, `RequestItem`s for exactly the requested items with reply-by date; the rest locked.
- Home `NextStepCard` + timeline + updates feed wired for stages 0–3.

### SR console
- **My startups** action queue (due-sorted, overdue first) and **Team view** (super admin default; RM read-only), with intake and screening metrics.
- Application review screen: application snapshot left, scorecard right (criteria from `SCREENING_CRITERIA` policy: score, comment, evidence upload per criterion), running total, pass-mark hint if policy set (guides only), verdict + reason. Information required → item composer (each item word for word, optional due date default +7 days).
- Duplicate panel: linked prior applications (other seasons) with outcome.
- Notes on the record; history tab.

### Automation
- `application.submitted`: RM auto-assign (least open workload among active RMs, A-56), acknowledgement notification (all channels), duplicate check (CIN, website domain, founder email/phone – A-72), snapshot.
- Info-required auto-Hold at +7 days (A-41), reminders per cadence.
- Realtime keys: `application:{id}`, `queue:user:{rmId}`, SR team metrics.

### Projections
- Founder projector for Startup, Application, ScreeningScorecard (verdict label + items only, **no score, no comments, no reason**).

## Acceptance
- S01, S02, S03, S04, S33 (founder sees new RM name live).
- Founder API never returns scorecard numbers or internal reason (projector snapshot test).
- Submit blocked below 100% and after the window closes.

## Prompt to paste

```
Continue the Startup Singam build with phase P02. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P02-founder-intake-and-screening.md. Implement the founder portal screens (mobile-first), the SR console screens, the automation and the founder projections described in Scope, using the generic services from P00–P01. All founder-visible labels must come from the mapping in /spec/docs/02 and packages/copy. Realtime must update the RM queue when the founder submits and the founder portal when the RM records a verdict, without reload. Write unit, integration and Playwright tests for scenarios S01–S04 and S33 from /spec/docs/13, update the seed (startups at draft, submitted, info-required, on hold, proceed), run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
