# P11 – Deployment tracking, success fee, TDS and reconciliation

**Goal:** tranches are reported by the investor, confirmed by the founder and verified by Finance with bank evidence; verified tranches drive the season meter and create a success-fee task; Finance calculates per the agreement, the lead reviews, one invoice per verified tranche goes to Zoho Books; the founder pays net with TDS and later uploads Form 16A; the startup account is reconciled and closed.

**Depends on:** P10.
**Read first:** `docs/02` stages 17–18; `docs/03` stage 13; `docs/04` §4.3 C–D, five fee numbers; `docs/06` fees and money; `docs/07` Tranche, Success fee, Startup account; `docs/12` Finance Deployment/Success fee/Reconciliation, metric definitions.

## Scope

### Investor portal – transfers
- Per tranche: scheduled amount/date, Mark as sent (amount, date, UTR, proof), "You reported ₹X", "Startup confirmed receipt", "Verified", remaining to deploy. Season meter Deployed updates on verification.

### Founder portal – funds and success fee
- Funds: per investor committed / received / pending; per tranche Confirm receipt + bank statement upload.
- Success fee: invoices (amount only, status, due date), upload proof, enter TDS deducted, later upload Form 16A; reminders until uploaded.

### IR console
- Fund follow-up: chase investor/founder; record "sent" on investor's behalf.

### Finance console
- Deployment verification: investor report vs founder confirmation vs bank evidence side-by-side; record verified amount, date, verifier, remaining commitment. Reversals linked to the original tranche (reduce deployed and fee base).
- Success fee: auto task on `tranche.verified`; calculator applying the MoU's agreement structure (percent / fixed / slab, cap, eligible vs excluded funding, upfront adjustment only if allowed, discounts, waivers; partner share field hidden unless switched on); Finance lead review; invoice per tranche; Zoho sync.
- Collect and allocate: cash + TDS allocation; status Paid (TDS certificate pending) → Paid.
- Reconciliation ledger per startup: upfront charges, success fees, receipts, GST, TDS, credits, partner settlements (if on); balance check; credit note when a reversal follows an invoice; close requires balanced + all TDS certificates (Finance lead).
- Five fee numbers per startup and in aggregate.

### SR console
- Success fee follow-up.

## Acceptance
- S26, S27, S28. One invoice per verified tranche (unique constraint). Money arithmetic property tests (no rounding drift; slabs and caps).

## Prompt to paste

```
Continue the Startup Singam build with phase P11. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P11-deployment-success-fee-reconciliation.md. Implement tranche reporting, founder confirmation and Finance verification with reversals; the live season meter Deployed figure; the success fee calculator, review, per-tranche invoicing and Zoho sync; TDS and Form 16A handling; and the reconciliation ledger with the five separate fee numbers. Use integer paise and basis points only, with property-based tests for the calculator. Cover S26–S28 with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
