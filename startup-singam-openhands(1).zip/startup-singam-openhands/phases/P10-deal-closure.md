# P10 – Deal closure (one deal room per investor)

**Goal:** for each confirmed deal, one accountable IRM records the communication thread within 48 h, runs the term sheet, coordinates due diligence (Legal tasks and findings), definitive agreements and pre-funding conditions, tracks milestones and blockers, and handles revisions, withdrawals and replacement investors with super admin approval.

**Depends on:** P09.
**Read first:** `docs/02` stage 16; `docs/03` stage 12; `docs/04` §4.1 step 9, §4.4 steps 4–6, §4.5 step 13; `docs/06` Deals; `docs/07` Deal; `docs/08` `CONFIDENTIAL_DEAL`, approvals; `docs/12` IR Deals/Compliance, Legal.

## Scope

### IR console – deal room
- Header: startup, investor, committed amount, instrument, valuation, lead/co, conditions, accountable IRM, blocker + owner + next action.
- Communication thread: record channel (email/WhatsApp), opened at, reference; 48 h countdown from deal confirmation; breach flag.
- Milestones with expected dates (term sheet, DD, agreements, pre-funding conditions, tranches); days stuck.
- Term sheet: upload versions (from investor or team).
- DD: task list auto-created from `DD_CHECKLIST` template (A-34), owner department (Legal, Finance, IR, external advisor by name); IR confirms DD complete.
- Commitment changes: revision (new amount, reason) and withdrawal (reason) → `Approval(COMMITMENT_REVISION/WITHDRAWAL)`; on approved withdrawal open replacement-investor search (suggest from matching engine; record activity).
- Tranche schedule entry (amounts + dates) – used in P11.

### Legal console
- DD board across deals: document requests to the founder (`RequestItem`), review, findings with severity, resolution tracking; HIGH/CRITICAL must be resolved before agreements.
- Definitive agreements: SHA, SSA, others; drafts, signatories, signature tracking.
- Pre-funding conditions: list (IP assignment, board resolution, …), status; IR confirms met.
- Legal dashboard tiles.

### Finance console
- DD tasks owned by Finance (if any) in work queue.

### Founder portal
- Deal cards per investor: milestones + expected dates, DD document requests, agreements to sign (download → upload signed), conditions they must fulfil, withdrawal reason (A-38) and replacement status. No finding text (A-65), no investor confidential remarks.

### Investor portal
- Deal room per startup: thread opened at + countdown, term sheet upload, DD progress summary and queries addressed to the investor, findings resolved count, agreements, pre-funding conditions, milestones; request revision/withdrawal with reason.

### SR console
- Deal follow-up view: what the founder still owes (term sheet input, DD documents, signatures).

## Acceptance
- S23, S24, S25; withdrawal → replacement search visible to founder.

## Prompt to paste

```
Continue the Startup Singam build with phase P10. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P10-deal-closure.md. Implement the IR deal room, Legal DD board, agreements and pre-funding conditions, commitment revisions and withdrawals with super admin approval and replacement search, the founder deal cards, the investor deal room, and the SR deal follow-up view. Enforce the gates: high or critical findings resolved before agreements, conditions met before funding. Track the 48-hour thread rule. Cover S23–S25 with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
