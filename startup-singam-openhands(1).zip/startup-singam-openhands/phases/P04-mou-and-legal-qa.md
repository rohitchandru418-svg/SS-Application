# P04 – MoU, Legal Q&A, negotiation, discontinue

**Goal:** SR shares the MoU with a working-day clock; Legal holds the Q&A by day 4; the founder signs by day 7, negotiates (super admin approval, Legal v2, clock restart) or discontinues.

**Depends on:** P03.
**Read first:** `docs/02` stage 6; `docs/04` §4.1 step 6, §4.4 steps 1–2; `docs/06` Mou, MouVersion, MouResponse, LegalQa; `docs/07` MoU; `docs/08` approvals routing; `docs/10` clocks; `docs/12` SR MoU, Legal MoU.

## Scope

### SR console – MoU desk
- Generate MoU from the season's approved `FOUNDER_MOU` template version (file generation with startup fields filled – A-73), share → clock starts; day 4 and day 7 computed via working-day calendar.
- Record founder response on their behalf if they reply by email: **Signed** (signed copy upload, commercial schedule, exceptions, signature date – all required), **Negotiate** (reason), **Discontinue** (founder email, reason).
- Confirm a founder-uploaded signed copy (A-45).
- MoU list with statuses: shared, Q&A done, signed, negotiating, discontinued, past day 7.

### Legal console
- Q&A queue (due by day 4); log questions asked and answers given; mark held.
- Negotiation review: requested changes; after super admin approval, upload v2 (status `REDRAFTING → ready`), SR shares v2.

### Super admin
- `Approval(MOU_NEGOTIATION)` in inbox with the founder's reason and Legal's notes; approve terms / reject.

### Founder portal
- MoU screen: download current version, Q&A date, day-7 countdown, Sign & upload / Want to negotiate (reason) / Not proceeding (reason + confirm). Negotiation status "With the team"; v2 replaces v1 with restarted countdown; history of versions.

### Automation
- Past day 7 → flag + escalation (A-47). Reminders day 5, day 6, day 7.
- `mou.signed` → application `IRR` and `irr.requested` (consumed in P05 – in this phase emit the event and create the `Irr` row in `REQUESTED`).

## Acceptance
- S08, S09; discontinue path ends the application with reason.
- Sign blocked without all four required fields.

## Prompt to paste

```
Continue the Startup Singam build with phase P04. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P04-mou-and-legal-qa.md. Implement the MoU desk for SR, the Legal Q&A and negotiation screens, the super admin negotiation approval, and the founder MoU screen. Day 4 and day 7 must use the working-day calendar policy and restart when a revised MoU is shared. Emit mou.signed and create the IRR request record for P05. Cover S08 and S09 plus the discontinue path with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
