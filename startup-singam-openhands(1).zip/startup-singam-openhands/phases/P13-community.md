# P13 – Community and ecosystem

**Goal:** one person record with many roles, events with registrations and outcomes, referral chains that feed SR and IR without duplicates, and founder support requests.

**Depends on:** P02, P06.
**Read first:** `docs/02` stage 19; `docs/03` stage 15; `docs/04` §4.8; `docs/06` Person, Community; `docs/07` Support request, Referral; `docs/08` Community rows ("membership never grants access to deal information"); `docs/12` Community.

## Scope

### Community console
- Members: person 360 (roles founder / investor / mentor / partner / alumni, organisation, sector, geography, interests, relationship owner, communication preferences and permissions/consent, groups). Merge duplicates with audit. Mentors and partners have no login.
- Events: type, purpose, owner, budget (`Approval(EVENT_BUDGET)`), registrations, attendance, feedback, follow-up tasks, outcomes.
- Referrals: chain interaction → referral → lead → qualified → engaged → funded / other; original source and later contributors kept separately; link to existing startup/investor/person records (never duplicate); creating a startup referral notifies SR, an investor referral creates an `InvestorLead` for IR.
- Support requests: type (investor intro, mentoring, customer connection, hiring, follow-on funding), owner, deadline, outcome, founder feedback.
- Dashboard tiles.

### Founder portal
- Community: events (register), alumni and mentor directory (fields permitted by consent – A-20), support requests (create, track, give feedback).

### Investor portal
- Community: investor sessions and events, next-season deal flow (A-80), refer another investor.

### Visibility
- Community roles never widen access to applications, deals, IRRs or fees (test: a mentor-founder sees only their own startup).

## Acceptance
- S32.

## Prompt to paste

```
Continue the Startup Singam build with phase P13. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P13-community.md. Implement the Community console (person 360 with multiple roles and merge, events with budget approval, referral chains linked to existing records, support requests, dashboard) and the founder and investor community screens. Membership must never grant access to deal information; write tests for that. Cover S32, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
