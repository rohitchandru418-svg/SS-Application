# P05 – Investment Readiness Report (IRR)

**Goal:** Finance accepts the IRR request, gathers documents from the founder through word-for-word queries (SR in the loop), prepares versioned reports, the Finance lead reviews, the super admin approves, and IR accepts the handover – blocked until any conditional-proceed condition is cleared.

**Depends on:** P04.
**Read first:** `docs/02` stage 7; `docs/04` §4.1 step 7, §4.3 A; `docs/06` Irr, IrrVersion, IrrHandover, InfoRequest, ActionItem; `docs/07` IRR; `docs/08` IRR row; `docs/12` Finance IRR, SR IRR.

## Scope

### Finance console – IRR workspace
- Queue item on `irr.requested`; Accept.
- Send the founder the information checklist (from `IRR_INFO_CHECKLIST` template – A-74) as a set of `RequestItem`s; add ad-hoc queries (word for word, per-query due date). Accept / re-request responses. SR sees all queries and replies.
- Prepare report: upload or compose (A-75) → `IrrVersion` n; submit for Finance lead review → approve/return with comments; submit for super admin final approval (`Approval(IRR_FINAL)`).
- Every version kept with author, reviewer, approver and timestamps.

### SR console
- IRR follow-up: queries and status, nudge founder, clear the conditional-proceed task (if any).

### IR console
- "IRRs to accept" list; Accept handover → application `MATCHING` and `irr.handover_accepted`. Accept disabled with reason if blocking SR tasks are open.

### Founder portal
- Document scrutiny checklist: queries word for word, due dates, upload/reply, statuses; "The team is preparing your report" when nothing is open. No access to the IRR itself (A-76).

### Metrics
- SR and Finance IRR tiles: requested, accepted, documents missing, in review, awaiting super admin, approved, handed to IR. ("At risk of 2-week rule" computed in P09 when shoot dates exist; render 0.)

## Acceptance
- S10; S06 gate (handover blocked until condition cleared).

## Prompt to paste

```
Continue the Startup Singam build with phase P05. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P05-irr.md. Implement the Finance IRR workspace, SR IRR follow-up, the IR accept-handover step and the founder document-scrutiny checklist using the shared RequestItem pattern. Keep every IRR version, route final approval through the generic approvals service, and enforce the conditional-proceed gate on handover. Cover S10 and the S06 gate with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
