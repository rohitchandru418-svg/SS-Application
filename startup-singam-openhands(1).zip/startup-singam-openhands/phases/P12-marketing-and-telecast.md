# P12 – Marketing, telecast and public announcements

**Goal:** Marketing schedules the telecast for each approved episode, notifies founders, produces promo assets approved by the CEO, tracks founder posting, runs post-telecast activity, collects founder feedback (routed to Production), and publishes investment announcements only after the investor approves the wording.

**Depends on:** P09 (announcements need P11 figures).
**Read first:** `docs/02` stage 15; `docs/03` stage 14; `docs/04` §4.1 step 10, §4.6 step 10, §4.7; `docs/06` Marketing; `docs/07` Announcement, Promo asset; `docs/08` `PUBLICATION`; `docs/12` Marketing, Production Content.

## Scope

### Marketing console
- Telecast schedule from approved episodes: air date (with broadcaster), status scheduled/aired.
- Founder notification of air date and promotion requirements (SR in loop).
- Promo assets: upload AVs, videos, posts per startup/episode → `Approval(PROMO_ASSET)` (super admin/CEO) → share approved assets + posting brief to the founder.
- Founder posting tracker: Posted / Not posted with post links; completion %. No reach or view metrics.
- Post-telecast activity log.
- Feedback inbox: founder ratings and comments; route to Production (and log actions there).
- Announcements: draft wording with figures pulled from the system (announced, committed, verified deployed – labelled), claim flag when announced ≠ deployed; send to investor for approval; publish only after approval (founder approval not needed).

### Founder portal
- Telecast & promotion: episode + air date, approved posts (download/copy), posting brief, submit post link per asset, mark done, feedback form after telecast; approved announcement wording once published.

### Investor portal
- Announcements: proposed wording with the three figures, Approve / Request change.

### Production console
- Founder feedback loop: feedback received, actions logged, Production head review.

### SR console
- Promotion follow-up.

## Acceptance
- S29, S30, S31. Marketing projector leak test (no investor remarks or deal documents).

## Prompt to paste

```
Continue the Startup Singam build with phase P12. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P12-marketing-and-telecast.md. Implement the Marketing console (telecast schedule, founder notification, promo assets with CEO approval, posting tracker, post-telecast log, feedback routing, announcements with investor approval and claim flags), the founder telecast and promotion screen, the investor announcement approval screen, and the Production feedback loop. Marketing must only see publication information. Cover S29–S31 with tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
