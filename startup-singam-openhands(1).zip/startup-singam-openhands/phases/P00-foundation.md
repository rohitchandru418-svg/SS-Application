# P00 – Foundation

**Goal:** a running monorepo with auth, roles, the permission engine, audit, the event outbox, realtime, notifications, files, the working-day calendar, three app shells and the design-system slot. No business workflows yet, but every later phase plugs into these.

**Depends on:** nothing.
**Read first:** `AGENTS.md`, `docs/01`, `docs/06` (Identity, Cross-cutting), `docs/08`, `docs/09`, `docs/10` §10.1–10.2, `docs/11` §11.1–11.2.

## Scope

### Repository & tooling
- pnpm + Turborepo monorepo with the layout in `AGENTS.md` §5. ESLint, Prettier, `tsconfig` strict, Vitest, Playwright, Testcontainers.
- `docker-compose.yml`: Postgres 16, Redis 7, MinIO, Mailpit. `.env.example`. `pnpm dev` runs api, worker, web.
- CI workflow (GitHub Actions): install, lint, typecheck, unit, integration, e2e.

### Database (Prisma)
- `User`, `Department`, `RoleAssignment`, `Assignment`, `Person`, `File`, `Note`, `AuditLog`, `OutboxEvent`, `Notification`, `Deadline`, `Approval` (table only), `Escalation` (table only), `Policy`, `PolicyVersion` (needed for the calendar).

### Auth
- External: email or phone OTP (6 digits, 10 min, rate-limited). Internal: email + password + TOTP MFA. Sessions via httpOnly cookies, CSRF protection. (A-59)
- Invite flow for internal users (super admin creates → email invite → set password + MFA).
- Seeded super admin from env.

### Permission engine (`packages/domain/permissions`)
- `can(viewer, action, resource)`, `scope(viewer, resourceType)` → Prisma `where`, `project(viewer, resource)` → whitelisted fields using visibility classes from `08`.
- NestJS guard + interceptor: every controller method declares its action; every response passes through `project`.
- Unit tests: matrix tests driven by a YAML fixture of (role, action, resource, expected).

### Commands, audit, outbox
- `defineCommand({ name, permission, input: ZodSchema, handler })` helper that wraps a Prisma transaction, writes `AuditLog` (before/after diff, reason, onBehalfOf) and lets the handler `emit(event)` into `OutboxEvent`.
- State-machine helper: `defineMachine({ states, transitions: [{from,to,by,guard}] })`, `transition(entity, to, ctx)` throws `IllegalTransitionError`.

### Worker
- Outbox relay (LISTEN/NOTIFY + 1 s polling fallback), idempotent consumer base class with processed-events table.
- Deadline scheduler (minute job + delayed jobs) with re-check hook.

### Realtime
- `GET /realtime/stream` SSE (auth required), Redis pub/sub `user:{id}` channels, heartbeat 25 s, `Last-Event-ID` support.
- Publisher in worker maps event → resource keys → permitted users (registry that later phases extend).
- Web hook `useRealtime()` that invalidates TanStack Query keys.

### Notifications
- `Notification` model; channels in-app, email (SMTP → Mailpit), WhatsApp (stub adapter, A-02). Template registry in `packages/copy/notifications`. Preferences per user. In-app bell with unread count (live).

### Files
- Presigned upload/download, scan stub, classification, `redactedVariantOf` column, `DocumentViewer` watermark mode (server renders PDF pages to images with watermark text; implement now with a generic test PDF).

### Working-day calendar
- `WORKING_DAY_CALENDAR` policy type (weekends + holiday list, versioned). `addWorkingDays`, `workingDaysBetween`, `isWorkingDay` with tests (holiday on Friday, year boundary, version change mid-period).

### Web shells
- Route groups `(founder)` (mobile-first, bottom nav), `(investor)` (top bar + season meter slot), `(internal)` (side nav by role, global search placeholder, approvals badge placeholder).
- Login screens for each. Role-based redirect after login.
- `packages/ui`: all placeholder components listed in `docs/11` §11.1 with documented props and Storybook (or Ladle) stories. **No colours/typography.**
- `packages/copy`: string registry with typed keys.

### Seed
- One user per internal role; one founder; one investor; working-day calendar v1 for the current year with weekends only (holidays to be supplied – A-66).

## Acceptance
- `docker compose up && pnpm dev` works from a clean clone; login works for each seeded role and lands in the right shell.
- A demo command `notes.add` on a `Person` writes audit + outbox, the worker publishes, and a second browser logged in as another permitted user sees the note appear live; a non-permitted user does not receive the key.
- Permission matrix tests pass; `project()` denies unknown fields by default.
- Working-day tests pass.

## Prompt to paste

```
You are building the Startup Singam application. Read /spec/README.md, /spec/AGENTS.md and every file listed under "Read first" in /spec/phases/P00-foundation.md before writing code. Then implement everything in the Scope section of P00 exactly, following the stack and architecture rules in AGENTS.md. Do not implement any business workflow beyond the demo command. Do not add colours, fonts or a design system: packages/ui must contain unstyled accessible placeholders with stable props. Write the tests listed in Acceptance, run lint, typecheck, unit, integration and e2e tests, and fix failures until they pass. Record any assumption you had to make in /spec/docs/99-assumptions-and-gaps.md under "Added during build". Finish with a summary of what was built, how to run it, and anything left open.
```
