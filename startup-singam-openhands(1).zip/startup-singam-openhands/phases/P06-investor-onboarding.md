# P06 – Investor onboarding, verification, grading, season allocation

**Goal:** investors express interest, register, complete a profile, sign the participation agreement and NDA, get verified against eligibility rules, are graded internally (super admin approves), and confirm a season allocation; the season meter appears.

**Depends on:** P01. Can be built in parallel with P02–P05.
**Read first:** `docs/03` stages 0–4; `docs/04` §4.5 steps 1–4, IR dashboards; `docs/06` Investor side; `docs/07` Investor; `docs/08` `GRADE`, Investor rows; `docs/12` IR Investors, Grades, Capital.

## Scope

### Public + investor portal
- Public "Express interest" form (name, entity, contact, referred by – optional person lookup, CAPTCHA) → `InvestorLead`, dedupe, invite to register.
- Registration (OTP), profile wizard (all fields in `03` stage 1) with save-and-resume.
- Agreements: Participation agreement and NDA from approved templates; download → upload signed; sign-by date; statuses.
- Verification: status "In progress" / "More information needed" (exact items as `RequestItem`s) / "Verified".
- Season commitment: show proposed allocation + max per startup; Confirm (or "Request a change" – A-24).
- Season meter component in the investor header (Allocation · Committed · Deployed · Available), live.
- Home with NextStepCard and IRM name.

### IR console
- **My investors** queue; **Team view** (super admin; IRMs read-only) with grade approvals waiting.
- Investor record: complete record fields including source/referral, portfolio and reference checks; verification evidence; eligibility check button evaluating the `INVESTOR_ELIGIBILITY` policy version (store result + version).
- Grading: score each `GRADING_DIMENSIONS` dimension with evidence, propose L1–L4, review date, reason for changes → `Approval(INVESTOR_GRADE)`.
- Season allocation: propose amount + max per startup (kept separate from commitments).
- Legal: view/confirm agreements.

### Automation
- IRM auto-assign on registration/referral (least loaded).
- Grade review date → "grade reviews due" metric.

### Projections
- Investor projector: never returns grade, dimensions, eligibility internals, reference checks, internal notes.

## Acceptance
- S11. Grade absent from every investor API response (snapshot test). Meter values derived (not stored) and live.

## Prompt to paste

```
Continue the Startup Singam build with phase P06. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P06-investor-onboarding.md. Implement the public interest form, the investor portal onboarding screens with the live season meter, and the IR console investor record, verification, eligibility, grading (with super admin approval) and allocation screens. The investor's grade must never leave the server for an investor viewer. Cover S11 with tests, extend the seed (investors at lead, profile complete, verifying, graded, active), run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
