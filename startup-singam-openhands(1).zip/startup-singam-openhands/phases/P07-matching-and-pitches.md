# P07 – Matching, IRR sharing, virtual pitch, Pitch Day, Golden Pass

**Goal:** the system suggests investors for each startup with an accepted IRR, the IRM approves circulation, each investor–startup pairing becomes its own record, investors view the IRR in-system only, accept or decline, pitch virtually, give verdicts, and continue to Pitch Day where Golden Passes and written commitments are recorded.

**Depends on:** P05, P06.
**Read first:** `docs/02` stages 8–9; `docs/03` stages 5–8; `docs/04` §4.5 steps 5–8; `docs/05` sync matrix rows for pairings; `docs/06` Matching, pitches, selection; `docs/07` Pairing; `docs/08` `MATCH_INTERNAL`/`MATCH_EXTERNAL`, IRR viewer; `docs/09` §9.6; `docs/12` IR Matching, Pitches, Interest conversion; SR Pitches.

## Scope

### Matching engine
- On `irr.handover_accepted`, score all `ACTIVE` investors with unused allocation: factors sector, stage, cheque size vs ask and max per startup, geography, thesis (keyword/tag overlap – A-77), grade, unused allocation; weights from `MATCHING_WEIGHTS`. Store total + per-factor breakdown. Suggest the top N (default 6 – spreadsheet says 5–6 matches per investor; A-78).
- Matching board (IRM): per startup, ranked suggestions with breakdown; approve circulation (bulk), discard; per investor, see how many active matches they hold. Coverage metric "startups with fewer than 3 matches".

### Pairing record (internal)
- Version of IRR shared + date, response, meetings + acknowledged minutes, questions and document requests, indicative amount, next action + deadline, pass or withdrawal reason; notes; history.

### Investor portal
- Your matches: cards with match % and external breakdown (sector, stage, ticket, geography only), respond-by date.
- IRR viewer: server-rendered watermarked pages, no download/print, version + date shared; log each open.
- Ask a question / Request a document → routed to IRM, who forwards to SR/Finance to get the founder's answer (A-40); answer returns to the pairing.
- Indicative amount (labelled Indicative). Accept / Decline (reason).
- Virtual pitches: team-proposed slots to approve, joining link, acknowledge minutes, verdict form (Ready to invest → amount, valuation range, instrument, conditions, labelled indicative / Next stage / Information requested / Pass). After verdict due date: system records No response.
- Pitch Day: approve 1:1 slots, information memorandum (view only), follow-on interest; Golden Pass and written commitment shown once recorded.

### Founder portal
- Investors screen: one card per investor (shown once the investor has accepted the match – A-37): slots available to book (only investor-approved slots), booked slot + link, information requests from that investor as `RequestItem`s, verdict per investor (incl. On hold – A-48), Pitch Day slots and outcome (Golden Pass / Written commitment / No response / Pass).

### IR console – pitches
- Scheduler: propose slots (5 min pitch + 5 min Q&A blocks), conflict detection across both parties, meeting link via adapter, attendance, materials, Q&A log, minutes upload.
- Verdict recorder on behalf (source note required).
- Pitch Day planner: map startups to investors, propose slots, distribute IRR and information memorandum, record outcomes, Golden Pass with issuer (no minimum commitment), written commitments, HNI follow-on interest and further discussions with deadlines.

### SR console
- Lifecycle view "Selection" track (matched investors, virtual pitch, Pitch Day, Golden Passes) – view, notes, follow-up.

## Acceptance
- S12, S13, S14, S15. Investor cannot open any IRR not circulated to them (S35 subset). Indicative amounts and Golden Passes do not change the meter's Committed.

## Prompt to paste

```
Continue the Startup Singam build with phase P07. Read /spec/AGENTS.md and every file under "Read first" in /spec/phases/P07-matching-and-pitches.md. Implement the matching engine with stored per-factor breakdowns, the IRM matching board and pairing record, the watermarked view-only IRR viewer with view logging, the investor match/pitch/Pitch Day screens, the founder investor cards, and the IR scheduler, verdict-on-behalf and Pitch Day tools. Slots must follow the rule: team proposes, investor approves, founder books. Keep internal match factors (grade, thesis weighting, unused allocation) out of investor responses. Cover S12–S15 with multi-context Playwright tests, extend the seed, run all tests and fix failures. Record assumptions in /spec/docs/99-assumptions-and-gaps.md.
```
