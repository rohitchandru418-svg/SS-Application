# 06 – Domain model (one shared database)

Conventions: every table has `id` (UUID v7), `createdAt`, `updatedAt`, `createdById`, `version` (optimistic lock). Money = `BigInt` paise + `currency`. Every status column is an enum defined in `07-state-machines.md`. Every deadline-bearing record has `dueAt`, `dueRule`, `originalDueAt` (if extended), `policyVersionId` (when derived from a policy). Soft delete only where stated; financial and audit records are never deleted.

Each entity lists a **visibility class** per sensitive field (see `08`): `PUBLIC_TO_OWNER` (external owner can see), `INTERNAL` (all internal roles with record access), `CONFIDENTIAL_DEAL` (hidden from Production, Marketing, Community, Analyst), `FOUNDER_PII` (hidden from Analyst everywhere), `GRADE` (IR + super admin only), `SCORE` (owning team + super admin only).

## Identity and organisation

| Entity | Key fields | Notes |
|---|---|---|
| `User` | email, phone (WhatsApp), name, kind (`EXTERNAL_FOUNDER`, `EXTERNAL_INVESTOR`, `INTERNAL`), status, lastLoginAt, notificationPrefs | One login per startup / per investor |
| `Department` | code (`SR`, `IR`, `FINANCE`, `LEGAL`, `PRODUCTION`, `MARKETING`, `COMMUNITY`, `ANALYST`, `MANAGEMENT`) | |
| `RoleAssignment` | userId, role (`RM`, `IRM`, `ANALYST`, `FINANCE_MEMBER`, `FINANCE_LEAD`, `LEGAL_MEMBER`, `PRODUCTION_COORDINATOR`, `PRODUCTION_HEAD`, `MARKETING_MEMBER`, `COMMUNITY_MEMBER`, `SUPER_ADMIN`), departmentId, active | A user may hold several roles |
| `Assignment` | subjectType (`STARTUP`, `INVESTOR`, `DEAL`, `APPLICATION`), subjectId, role, userId, assignedBy (`SYSTEM` or userId), reason, activeFrom, activeTo | History kept on reassignment |
| `Person` | name, emails, phones, organisation, sector, geography, interests, communicationPrefs, consentFlags, relationshipOwnerId, groups | Community master record; links to `User`, `Founder`, `Investor`, mentor/partner roles (`PersonRole`) |

## Season and policy

| Entity | Key fields |
|---|---|
| `Season` | name, applicationOpensAt, applicationClosesAt, status (`DRAFT`, `OPEN`, `CLOSED`, `ARCHIVED`), feeSchedulePolicyVersionId, committee members (`SeasonCommitteeMember`: personId, role) |
| `Episode` | seasonId, number, title, plannedShootDate, airDate, status |
| `Policy` | type (`SCREENING_PASS_MARK`, `INVESTOR_ELIGIBILITY`, `UPFRONT_FEE_SCHEDULE`, `SUCCESS_FEE_DEFAULTS`, `WORKING_DAY_CALENDAR`, `SCREENING_CRITERIA`, `ANALYST_CRITERIA`, `GRADING_DIMENSIONS`, `MATCHING_WEIGHTS`, `REMINDER_CADENCE`) |
| `PolicyVersion` | policyId, version, effectiveFrom, effectiveTo, body (JSON validated by a Zod schema per type), approvedById |
| `Template` | type (`FOUNDER_MOU`, `PARTICIPATION_AGREEMENT`, `NDA`, `INVESTMENT_COMMITMENT_LETTER`, `STARTUP_DEAL_ACCEPTANCE_LETTER`, `TERM_SHEET`, `DD_CHECKLIST`, `IRR_INFO_CHECKLIST`) |
| `TemplateVersion` | templateId, version, fileId, status (`DRAFT`, `PENDING_APPROVAL`, `APPROVED`, `RETIRED`), approvedById |

## Startup side

| Entity | Key fields | Visibility notes |
|---|---|---|
| `Startup` | legalName, brandName, sector, stage (`IDEA`, …), geography, website, incorporation (CIN), financials (per FY), ownerUserId | Contacts `FOUNDER_PII` |
| `Founder` | startupId, personId, name, email, phone, role, isPrimary, userId (primary only) | `FOUNDER_PII` |
| `StartupDocument` | startupId, kind, fileId, fy, uploadedById | |
| `Application` | startupId, seasonId, status, completenessPct, missingItems[], submittedAt, snapshot (JSON of profile at submit), duplicateOfApplicationIds[] | |
| `ScreeningScorecard` | applicationId, rmId, criteria[] {criterionId, score, comment, evidenceFileIds}, total, verdict, reason, policyVersionId | `SCORE` (SR + super admin) |
| `InfoRequest` (generic "request item") | subjectType, subjectId, requestedById, audience (`FOUNDER`, `INVESTOR`), text (shown word for word), dueAt, status, responseText, responseFileIds, source (`SCREENING`, `IRR`, `DD`, `VERIFICATION`, `PAIRING_QUESTION`, `PAIRING_DOC_REQUEST`) | Used across the product |
| `BootcampBatch` | seasonId, name, sessions[] |
| `BootcampParticipation` | batchId, applicationId, inviteStatus, attendance per session, briefings {process, readiness, mouAndFee, questionsAnswered}, preparationStatus |
| `ActionItem` | subjectType, subjectId, title, assigneeType (`FOUNDER`, `INTERNAL`), assigneeId, dueAt, status, source | Founder action items, SR tasks (e.g. conditional-proceed condition) |
| `AnalystReferral` | applicationId, analystId, status, dueAt | |
| `AnalystEvaluation` | referralId, scores {thesisFit, marketOpportunity, traction, businessModelScalability, competitivePositioning}, willingnessToInvest, indicativeAmount, recommendation, reason, outstandingConcern, condition (if conditional) | `SCORE`; never founder/investor |
| `Mou` | applicationId, status, currentVersionId, clockStartedAt, legalQaDueAt (wd 4), signDueAt (wd 7) |
| `MouVersion` | mouId, version, templateVersionId, fileId, sharedAt |
| `MouResponse` | mouId, type (`SIGNED`, `NEGOTIATE`, `DISCONTINUE`), signedFileId, commercialSchedule, exceptions, signatureDate, reason, founderEmail |
| `LegalQa` | mouId, heldAt, entries[] {question, answer} |
| `Irr` | applicationId, status, acceptedById, requestedById |
| `IrrVersion` | irrId, version, fileId (render source), preparedById, reviewedById, approvedById, approvedAt |
| `IrrHandover` | irrVersionId, acceptedByIrmId, acceptedAt |

## Investor side

| Entity | Key fields | Visibility notes |
|---|---|---|
| `InvestorLead` | name, contact, referredByPersonId, source, status | |
| `Investor` | userId, personId, category, investingEntity, decisionMaker, authorisedRepresentative, sectors[], stages[], geographies[], thesis, ticketMin, ticketMax, portfolio[], referenceChecks[], availability, decisionTimeline, status | |
| `InvestorAgreement` | investorId, type (`PARTICIPATION`, `NDA`), templateVersionId, signedFileId, status, signByAt |
| `Verification` | investorId, status, evidence[], eligibilityResult {policyVersionId, passed, failures[]} |
| `Grade` | investorId, dimensions[] {dimensionId, score, evidence}, proposedLevel (`L1`–`L4`), approvedLevel, reviewDate, reason, status | `GRADE` |
| `SeasonAllocation` | investorId, seasonId, allocationAmount, maxPerStartup, status (`PROPOSED`, `CONFIRMED`) | Investor sees own |
| `SeasonMeter` (derived view) | allocation, committed, deployed, available | Computed, never stored as truth |

## Matching, pitches, selection

| Entity | Key fields |
|---|---|
| `Pairing` | startupId(application), investorId, irmId, matchScore, matchBreakdown, status, irrVersionSharedId, sharedAt, respondByAt, response, declineReason, indicativeAmount, nextAction, nextActionDueAt, passReason, withdrawalReason |
| `IrrViewLog` | pairingId, investorUserId, openedAt, durationSec, irrVersionId |
| `PitchSlot` | pairingId, round (`VIRTUAL`, `PITCH_DAY`), startsAt, endsAt, proposedById, investorApprovedAt, founderBookedAt, joinUrl, status |
| `PitchMeeting` | slotId, attendance {founder, investor}, materials[], qa[], minutesFileId, investorAckAt, founderAckAt |
| `Verdict` | pairingId, round, value, recordedBy (investor or IRM on behalf), onBehalf (bool), sourceNote, dueAt, indicative {amount, valuationMin, valuationMax, instrument, conditions} |
| `GoldenPass` | pairingId, issuerInvestorId, issuedAt, notes |
| `WrittenCommitment` | pairingId, amount, terms, fileId, recordedById, stage (`PITCH_DAY`, `PRE_SHOOT`) |
| `FollowOnInterest` | pairingId, notes, deadline |
| `InformationMemorandum` | applicationId, fileId, version |
| `CommitteePack` | applicationId, sections {evaluation, irr, investorFeedback, goldenPasses, unresolvedQuestions, proposedParticipation, productionReadiness, commercialStatus}, compiledById |
| `CommitteeDecision` | packId, decision (`PROCEED`, `ON_HOLD`, `REJECTED`), conditions, approverPersonIds, decisionDate, reReviewDate, recordedById, internalReason |

## Fees and money

| Entity | Key fields |
|---|---|
| `UpfrontFee` | applicationId, seasonId, status, clockStartedAt, dueAt, originalDueAt, fy, turnover, turnoverEvidenceFileIds, feeSchedulePolicyVersionId, calculatedAmount, exceptions[], approvedById, lateReason, managementDecision |
| `Invoice` | type (`UPFRONT`, `SUCCESS`), subjectId, number, amount, gst, dueAt, originalDueAt, status, zohoId, zohoSyncStatus |
| `PaymentProof` | invoiceId, fileId, amount, paidOn, uploadedById, tdsDeducted, status (`UPLOADED`, `VERIFIED`, `REJECTED`) |
| `Receipt` | invoiceId, amount, tdsAmount, bankRef, verifiedById, verifiedAt, allocation |
| `Extension` | invoiceId, requestedById, reason, requestedDays, newDueAt, approverRole, status |
| `FinanceException` | type (`DISCOUNT`, `SPLIT_PAYMENT`, `WAIVER`, `REFUND`, `DISPUTE`), subjectId, amount, reason, status, approvalId |
| `Tranche` | dealId, sequence, scheduledAmount, scheduledDate, investorReportedAmount, investorReportedAt, utr, proofFileId, founderConfirmedAt, founderBankStatementFileId, verifiedAmount, verifiedAt, verifiedById, status |
| `Reversal` | trancheId, amount, reason, recordedAt, creditNoteId |
| `SuccessFeeCalculation` | trancheId, agreementStructure {type (`PERCENT`, `FIXED`, `SLAB`), rateBp, fixedAmount, slabs[], cap, eligibleFunding, excludedFunding, upfrontAdjustmentAllowed}, discounts, waivers, partnerShare (off by default), amount, reviewedById |
| `TdsCertificate` | invoiceId, fileId, form (`16A`), uploadedAt, status |
| `StartupAccount` (ledger) | applicationId; `LedgerEntry` rows (charge, receipt, TDS, GST, credit note, partner settlement) ; status (`OPEN`, `BALANCED`, `CLOSED`) |
| `FeeMetrics` (derived) | forecast, due, invoiced, collected, outstanding |

## Production and show

| Entity | Key fields |
|---|---|
| `ProductionRecord` | applicationId, coordinatorId, status, advanceNoticeAt, likelyEpisodeId, roughSchedule |
| `HandoverPack` | productionRecordId, assembledAt, contents (snapshot of permitted fields), irApprovedById, productionAcceptedById, status |
| `Shoot` | productionRecordId, type (`AV`, `MOCK`, `MAIN`), scheduledAt, location, crew, shotRequirements, founderAvailability, status, assetLinks[] |
| `ReadinessChecklist` | shootId, items[] {category (`COSTUME_PROPS`, `PITCH`, `DEMO`, `STAGE`, `FINAL_ASK_VALUATION`, `OPEN_ACTION`), title, owner (`FOUNDER`/`INTERNAL`), status} |
| `EpisodeAllocation` | applicationId, episodeId, shootDate, approvedById |
| `PanelMember` | episodeId, applicationId, investorId, role, proposedCommitment, valuationBounds, decisionParameters, writtenConfirmationAt, briefingAckAt, irrReceivedAt |
| `SigningEvent` | shootId or dealId, type (`INVESTOR_COMMITS_ON_SET`, `FOUNDER_ACCEPTS_DEAL`, …), requiredTemplateType, dueAt, signedFileIds, status | Drives document requirements (document rule) |
| `OnSetOffer` | shootId, investorId, ask, offer {amount, equity/valuation, instrument}, accepted, leadOrCo, conditions |
| `ShootException` | shootId, type (`FOUNDER_NO_SHOW`, `INVESTOR_ABSENT`, `DEAL_WITHDRAWN`, `SIGNATURE_REFUSED`, `TECHNICAL_FAILURE`), notes, followUp |
| `EpisodeEdit` | episodeId, status, reviewedByHeadAt, approvedById |

## Deals

| Entity | Key fields |
|---|---|
| `Deal` | applicationId, investorId, irmId, committedAmount, instrument, valuation, leadOrCo, conditions, status, blocker, blockerOwnerId, nextAction |
| `CommunicationThread` | dealId, channel (`EMAIL`, `WHATSAPP`), openedAt, dueAt (deal confirmed + 48 h), reference |
| `DealMilestone` | dealId, type (`TERM_SHEET`, `DD`, `AGREEMENTS`, `PRE_FUNDING_CONDITIONS`, `FIRST_TRANCHE`, …), expectedDate, status |
| `TermSheet` | dealId, fileId, version, sharedBy |
| `DdTask` | dealId, ownerDept (`LEGAL`, `FINANCE`, `IR`, `ADVISOR`), advisorName, title, infoRequestId, status |
| `DdFinding` | dealId, severity (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`), description, resolution, status |
| `Agreement` | dealId, type (`SHA`, `SSA`, `OTHER`), fileId, signatories[], status |
| `PreFundingCondition` | dealId, title, status, confirmedByIrmId |
| `CommitmentChange` | dealId, type (`REVISION`, `WITHDRAWAL`), oldAmount, newAmount, reason, approvalId, replacementInvestorId |

## Marketing

| Entity | Key fields |
|---|---|
| `Telecast` | episodeId, airDate, broadcaster, status |
| `PromoAsset` | episodeId, applicationId, type (`AV`, `VIDEO`, `POST`), fileId, status, approvalId |
| `PostingTask` | applicationId, assetId, brief, postLink, status (`NOT_POSTED`, `POSTED`) |
| `Feedback` | applicationId, source (`FOUNDER`), rating (1–5), comments, routedTo[], actions[] |
| `Announcement` | dealId(s), wording, figures {announced, committed, verifiedDeployed}, status, investorApprovedAt, publishedAt, claimFlag (announced ≠ deployed) |

## Community

| Entity | Key fields |
|---|---|
| `Event` | type, purpose, ownerId, budget, budgetApprovalId, date, status, outcomes |
| `EventRegistration` | eventId, personId, attended, feedback |
| `Referral` | referrerPersonId, subjectType (`STARTUP`, `INVESTOR`), linkedRecordId, originalSource, contributors[], stage (`INTERACTION`, `REFERRAL`, `LEAD`, `QUALIFIED`, `ENGAGED`, `FUNDED`, `OTHER`) |
| `SupportRequest` | applicationId/startupId, type, ownerId, dueAt, status, outcome, founderFeedback |
| `FollowUpTask` | eventId, title, ownerId, dueAt, status |

## Cross-cutting

| Entity | Key fields |
|---|---|
| `File` | storageKey, mime, size, sha256, uploadedById, scanStatus, classification (visibility class), redactedVariantOf |
| `Note` | subjectType, subjectId, authorId, body, visibility (department or all internal) |
| `Approval` | type (see super admin list), subjectType, subjectId, raisedById, approverRole, dueAt (2 working days), status, decidedById, decidedAt, reason |
| `Escalation` | type, subjectType, subjectId, cause, status, decisionText, decidedById |
| `AuditLog` | actorId, onBehalfOfId, action, subjectType, subjectId, before, after, reason, ip, at |
| `OutboxEvent` | type, aggregateType, aggregateId, payload, occurredAt, publishedAt |
| `Notification` | userId, channel (`IN_APP`, `EMAIL`, `WHATSAPP`), templateKey, payload, deepLink, status, sentAt, readAt |
| `Deadline` (index view) | subjectType, subjectId, kind, dueAt, ownerUserId, status | Drives action queues |
