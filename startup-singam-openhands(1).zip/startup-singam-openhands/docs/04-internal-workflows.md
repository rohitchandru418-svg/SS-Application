# 04 – Internal workflows

Each department's steps in order. **Owns** = this team performs and closes the step. **View & follow up** = the team sees status, adds notes and chases, but cannot change the record. Approvers and rules are binding.

---

## 4.1 Startup Relations (SR)

Roles: Super admin oversees SR (team view, reassignment). RMs are auto-assigned and score their own applications. Analysts are a separate persona from a pool. SR **owns steps 1–7**; steps 8–11 are **view & follow up**.

| # | Step | Trigger | What SR does | Output / gate | SR role | Rule | Hands to |
|---|---|---|---|---|---|---|---|
| 1 | New application | Founder submits | Alert; RM auto-assigned; acknowledgement sent automatically; duplicate check links repeat applicants; RM reviews completeness and documents | Application in RM's queue | Owns | Screening only after formal submission | — |
| 2 | Internal screening | RM picks up | RM scores 100-mark card (score, comment, evidence per criterion); verdict with reason: Proceed / Information required (specific items) / Hold / Reject | Verdict (founder sees verdict only) | Owns | Info required: founder has 7 days, else auto-Hold. No pass mark yet – RM decides, score guides (pass mark is a policy, empty by default) | — |
| 3 | Pre-bootcamp | Proceed | Invite to batch bootcamp; attendance; record process briefing, readiness sessions, MoU and upfront fee briefing, founder questions answered; assign action items | Preparation complete (not just attended) | Owns | Bootcamp dates | — |
| 4 | Send to analyst | Preparation complete | Send to analyst pool; system hides founder names and contacts automatically | Analyst assigned | Owns | — | Analyst |
| 5 | Review analyst decision | Analyst submits | Read recommendation; continue to MoU if Proceed / Conditional proceed. **SR cannot override an analyst Reject.** | MoU or stop | Owns | — | — |
| 6 | MoU | Analyst Proceed | Share MoU (clock starts); Legal Q&A by working day 4; signing deadline working day 7; record response: **Signed** (signed copy, commercial schedule, exceptions, signature date) / **Negotiate** (escalate to Management; revised MoU shared, clock restarts) / **Discontinue** (founder email and reason) | Signed MoU | Owns | Working day 4 and 7 | Management (negotiate), Legal |
| 7 | IRR handover | MoU signed | Raise IRR request; Finance/IRR accepts; IRR team posts document queries to founder with SR in loop; report prepared, reviewed, approved | Approved IRR handed to IR (IR accepts) | Owns request; follows queries | IRR with investors 2 weeks before shoot | Finance/IRR, then IR |
| 8 | Upfront fee follow-up | Committee Proceed | Chase founder with Finance; record late reason; pass extension requests to approver | Fee paid | View & follow up | 15 days from committee | Finance |
| 9 | Deal follow-up | After main shoot | Chase founder for term sheet, DD documents, signatures | Founder's part complete | View & follow up | Milestone dates | IR, Legal |
| 10 | Promotion follow-up | Telecast | Check founder posted approved content; collect post-telecast feedback | Done | View & follow up | Air date | Marketing |
| 11 | Success fee follow-up | Fee invoiced | Chase founder for payment with Finance | Collected | View & follow up | Invoice due date | Finance |

**Automatic handover to Production.** Nobody prepares the Production handover pack by hand. When Finance verifies the full upfront fee, the system assembles it from existing records (startup profile, founder contacts, selection decision, payment clearance, permitted business information). Production gets an *advance notice* earlier, when the committee says Proceed and the fee request is created.

**Lifecycle view (what SR watches):** Selection (matched investors, virtual pitch, Pitch Day, Golden Passes, committee result) · Production (AV / mock / main shoot status, blockers, accepted deal terms) · Investment (term sheet, DD, agreements, committed vs deployed) · Finance (upfront and success fee paid / overdue) · Marketing (content posted, feedback). All view, notes, follow-up.

---

## 4.2 Analyst

Internal staff with a single queue. See permitted business information only: founder and co-founder names and contacts hidden in screens, exports and shared documents. Analysts never contact founders; questions go through SR.

| # | Step | Trigger | What they do | Output | Rule |
|---|---|---|---|---|---|
| 1 | Receive | SR sends after preparation complete | Assigned from pool; appears in queue | In queue | Evaluation due in **5 working days**; overdue → escalated (A-27) |
| 2 | Evaluate | Picked up | Score thesis fit, market opportunity, traction, business model & scalability, competitive positioning; record willingness to invest and indicative amount. Questions to founder routed through SR (SR gets the documents) | Draft | — |
| 3 | Recommend & submit | Evaluation complete | Proceed / Conditional proceed / Hold / Reject + decision reason + outstanding concern. **Conditional proceed**: moves to MoU; the condition becomes an SR task that must be cleared before the IRR is handed to IR | SR notified; founder sees "Fit check done" | — |

Rules: interest is not money (analyst willingness/indicative amount never count as investor commitment); SR cannot override an analyst Reject; redaction is enforced by the system including exports.

---

## 4.3 Finance

Same people do IRR, fees, verification and reconciliation; Finance lead reviews and oversees. Super admin gives final approval on IRRs, fee exceptions, discounts, waivers, refunds, disputes and extensions over 7 days (Finance lead approves extensions ≤ 7 days – A-28). Accounting runs in Zoho Books. Legal (not Finance) does due diligence. One shared Finance dashboard with a work queue.

**A. IRR**
1. Accept IRR request (MoU signed; SR raises; automatic alert) → IRR in progress.
2. Gather information: send founder the information checklist; post queries for missing documents/clarifications (SR in loop); track each to resolution; per-query due dates → all documents in.
3. Prepare, review, approve: prepare report; Finance lead reviews; keep every version; **super admin final approval** → approved IRR handed to IR (IR accepts). Rule: IRR with investors 2 weeks before shoot.

**B. Upfront fee**
4. Fee request – automatic on committee Proceed; request per startup and season; 15-day clock starts.
5. Verify turnover – record FY, turnover, supporting evidence.
6. Calculate and approve – apply fee schedule (policy) and its version; record any exception (split payment, discount). Approver: Finance lead (standard), super admin (exceptions, discounts). Fee schedule still to be supplied (A-29).
7. Invoice – with due date; founder notified; sync to Zoho Books.
8. Follow up – chase with SR; record late reason and Management decision; an extension adds a new due date and keeps the original; ageing from original due date.
9. Verify and allocate receipt – founder uploads proof; check against bank; allocate to invoice. **A screenshot never marks it paid.** Paid → automatic AV handover pack to Production.

**C. Deployment verification**
10. Verify tranche – investor reports transfer; founder confirms receipt; check bank or approved evidence; record verified amount, date, verifier, remaining commitment. Returned money = reversal linked to the original (reduces deployed amount and fee base). Verified → automatic success-fee task.

**D. Success fee and reconciliation**
11. Calculate – check MoU and eligible funding; agreement structure: percentage / fixed / slab, cap, eligible vs excluded funding, upfront adjustment only if allowed, discounts, waivers. Partner-share field present but off by default.
12. Review and invoice – Finance lead reviews; **one invoice per verified tranche**; sync to Zoho Books.
13. Collect and allocate – founder pays net and enters TDS; allocate cash + TDS → Paid (TDS certificate pending).
14. Reconcile – balance the startup account: upfront charges, success fees, receipts, GST, TDS, credits, (partner settlements if on). Founder uploads Form 16A; reminders until then. Credit note if a reversal follows an invoice. Closed only when the account balances and TDS certificates are in. Approver: Finance lead.

**Five fee numbers, always separate:** Forecast (expected fee on anticipated funding) · Due (under the agreement on verified money) · Invoiced · Collected (verified receipts allocated incl. TDS) · Outstanding (unsettled balance after approved adjustments).

**Notifications to Production (one per event):** Committee Proceed → advance notice; full upfront fee verified → AV shoot handover pack.

---

## 4.4 Legal

In-house team; super admin oversees. Support function.

| # | Step | Trigger | Output | Approver | Rule |
|---|---|---|---|---|---|
| 1 | MoU clarification (Legal Q&A) | SR shares MoU; founder has questions | Q&A held by working day 4, questions and answers logged | — | Working day 4 |
| 2 | MoU negotiation support | Founder chooses Negotiate | Review requested changes; after super admin approves the negotiated terms, redraft MoU v2 → ready for SR to share (clock restarts) | Super admin | — |
| 3 | Templates | Season setup | Approved versions of: founder MoU, participation agreement, NDA, Investment Commitment Letter, Startup Deal Acceptance Letter, term sheet | Super admin | Before season opens |
| 4 | Due diligence | Deal confirmed (IR opens deal) | DD tasks inside the IR-owned deal: request documents from founder, review, log findings with severity, track each to resolution | IR confirms DD complete | Milestones |
| 5 | Definitive agreements | DD complete | Draft/review SHA, SSA, related; track signatures | — | Milestones |
| 6 | Pre-funding conditions | Agreements executed | Track each condition (IP assignment, board resolution…) to completion → transfer can proceed | IR confirms | Before tranche date |

---

## 4.5 Investor Relations (IR)

Super admin oversees IR, approves every grade and every revised or withdrawn commitment. IRMs auto-assigned. IR owns investors end to end and each deal through closure (one accountable IRM per deal). Finance owns receipt verification and fees; IR watches.

| # | Step | Trigger | What IR does | Output | Rule |
|---|---|---|---|---|---|
| 1 | New investor | Registers or referred | Alert; IRM auto-assigned; review interest | In IRM queue | — |
| 2 | Record & verification | IRM picks up | Complete record (category & entity, source & referral, decision-maker & authorised rep, sector/stage/geography/thesis, ticket size, portfolio & reference checks, availability & decision timeline); collect evidence; check configurable eligibility rules; participation agreement + NDA signed | Verified investor | Eligibility rules are policies |
| 3 | Grading | Verified | Score each grading dimension with evidence; propose L1–L4 (sets permitted engagement and panel role); review date; changes need a reason | Grade approved by super admin (internal only) | Grade review date |
| 4 | Season allocation | Graded | Proposed season allocation and max per startup, separate from commitments | Allocation set | — |
| 5 | Receive IRRs | SR hands over approved IRR | Accept handover | Startup ready to match | — |
| 6 | Matching | IRR accepted | System suggests investors (sector, stage, cheque size, geography, thesis, grade, unused allocation); IRM approves circulation. Each pairing is its own record (version shared, date, response, meetings & acknowledged minutes, questions & documents requested, indicative amount, next action & deadline, pass/withdrawal reason) | IRRs shared (view only) | — |
| 7 | Virtual pitch | Investor accepts match | Schedule (5 + 5 min); track attendance, material, Q&A; validate verdicts (investor submits, or IRM records on their behalf, e.g. from a call). Ready to invest → amount, valuation range, instrument, conditions (indicative) | Verdict per pairing | Verdict due date |
| 8 | Pitch Day | Next stage / ready to invest | Map startups to investors; propose slots (investor approves, founder books); distribute IRR and information memorandum; outcomes; record Golden Passes and issuer (no minimum commitment); HNI follow-on interest and further discussions with deadlines | Golden Passes & written commitments | Pitch Day date |
| 9 | Committee pack & decision | Pitch Day done | Compile pack (evaluation, IRR, investor feedback, Golden Passes, unresolved questions, proposed investor participation, production readiness, commercial status); record decision with conditions, approver, decision date, re-review date | Proceed / On hold / Rejected | — |
| 10 | Automatic triggers on Proceed | Decision recorded | **System**: creates Finance upfront fee request (15-day clock), sends Production advance notice, informs SR | — | 15 days |
| 11 | Pre-shoot confirmation | Committee Proceed | Build episode panel (grade and sector fit); written proposed commitment, valuation boundaries, decision parameters; production briefing; clear outstanding issues and documents | Panel confirmed | Alert if IRR not with panel investors 2 weeks before shoot |
| 12 | Main shoot | Shoot day | Oversee offers, accepted terms, lead/co-investor allocation, conditions, ICL and SDAL signatures (Production captures) | Deal confirmed | Signing deadline |
| 13 | Deal closure | Deal confirmed | One accountable IRM per deal: open communication thread on email/WhatsApp and record it; term sheet; coordinate DD (IR, Finance, Legal, advisors); findings; definitive agreements; pre-funding conditions; expected date per milestone; blocker, owner, next action. Revised commitments and withdrawals with reasons (super admin approves); replacement-investor activity | Signed deal, conditions met | Thread within 48 h; milestones |
| 14 | Fund follow-up | Tranche scheduled | Chase investor to transfer (investor marks sent, or IRM records) and founder to confirm; Finance verifies | Tranche verified | Tranche dates |
| 15 | Success fee & announcements | Tranche verified / telecast | Watch success fee; coordinate investor approval of public wording | — | — |

What IR watches: per investor (season meter, all pairings and stage, deals and tranches, announcements awaiting approval) – owns; per paired startup (Startup 360) – view, notes; other teams' steps (upfront fee, shoots, receipt verification, success fee) – view, follow-up.

---

## 4.6 Production & Show Operations

Production head (supervised by super admin); coordinators assigned per startup. Production sees permitted business information only; confidential investor remarks and deal documents hidden. Advance notice and AV handover are separate milestones.

| # | Step | Trigger | Output | Approver | Rule |
|---|---|---|---|---|---|
| 1 | Advance notice | Committee Proceed (auto) | Startup in planning list (likely episode, rough schedule, no booking) | — | — |
| 2 | Handover pack | Finance verifies full upfront fee (auto assembly) | Pack (profile, founder contacts, selection decision, payment clearance, permitted business info); **IR approves; Production accepts** → AV can be booked | IR approves pack | AV handover only after completed payment |
| 3 | AV shoot | Handover accepted | Story research, location, crew, schedule, founder availability, shot requirements; mark complete; save asset links | — | Shoot date |
| 4 | Episode allocation | AV done | Production + IR: startup → episode and shoot date; IR builds panel | Production head | IRR with investors 2 weeks before shoot |
| 5 | Pre-shoot documentation | Episode fixed | Documents per **signing event** (not by file name) | — | Before mock |
| 6 | Mock shoot | Pre-shoot docs ready | Costumes & props, pitch revisions, demo readiness, stage movement & rehearsal, final ask & valuation, open actions | **Super admin** approves final readiness | Before main |
| 7 | Main shoot | Readiness approved | On set: founder & investor attendance, live ask and offers, accepted terms, lead/co-investor allocation, conditions, ICL, SDAL, signatures done/outstanding; shoot-day exceptions | Deal confirmed → IR takes closure | Signing deadline |
| 8 | Post-shoot documentation | Main shoot done | Collect outstanding signatures (paper, uploaded) → shoot file complete | — | Same day / 24 h (A-14) |
| 9 | Editing & approvals | Shoot file complete | Edit; Production head reviews; final approval (proposed: super admin – A-30) | Super admin | Air date |
| 10 | Founder feedback loop | After telecast | Founder feedback routed to Production (and Marketing); actions logged | Production head | — |

**Shoot-day exceptions:** Founder no-show → reschedule, SR informed · Investor absent → panel adjusted, IR informed · Deal withdrawn on set → recorded with reason, IR starts replacement search · Signature refused → recorded, escalated to IR and super admin · Technical failure → reshoot scheduled.

**Document rule:** titles do not drive workflow. Each signing event (investor commits on set, founder accepts the deal) defines which document it needs and when. Shoot-day documents are signed on paper and uploaded.

---

## 4.7 Marketing & telecast

Takes the approved episode; owns telecast, promotions, founder posting, public announcements. Sees approved publication information only. (The sheet says "Yellow rows = Proposed" but no rows are highlighted – A-31.)

1. Telecast schedule – episode approved → record episode and telecast date (set with the broadcaster).
2. Founder notification – air date fixed → notify founder of air date and promotion requirements (SR in loop).
3. Promo assets – create AVs, videos, posts; **super admin (CEO)** approves; before air date.
4. Founder posting – share approved assets and posting brief; founder posts and submits link; status Posted / Not posted (no reach or view metrics).
5. Post-telecast activity – run and log.
6. Founder feedback – collect; route content feedback to Production.
7. Public investment announcement – on deal milestone: draft wording from system figures labelled announced / committed / verified deployed; **publish once the investor approves** (founder approval not needed).

---

## 4.8 Community & ecosystem (version 1)

Lead engine (startup and investor leads) and ecosystem. Community team manages all member records; mentors and partners have no logins. **Membership never grants access to deal information.** No SOP exists; this follows the proposed module.

1. Member records – one person record with multiple roles (founder + mentor + investor…); organisation, sector, geography, interests, relationship owner, communication preferences and permissions, groups.
2. Events – purpose, owner, budget (super admin approves budget), registrations, attendance, feedback, follow-up tasks, outcomes (founder meetups, investor sessions, sector roundtables, partner programmes, mentoring clinics, alumni activities).
3. Referrals – chain interaction → referral → application / investor lead → qualified → engaged → funded or other outcome; keep original source and later contributors separately; link to existing records, never duplicate.
4. Founder support – investor intros, mentoring, customer connections, hiring, follow-on funding; owner, deadline, outcome, founder feedback.

---

## 4.9 Super admin / Management

CEO, directors, managing partners; any one can approve and the system records who. Oversee every department; approve exceptions; own policies and season setup. **Every approval has a 2-working-day deadline** and shows overdue on the dashboard.

1. Approvals inbox – one inbox for all approvals, sorted by due date; approve / reject with reason.
2. Escalations – missed deadlines, MoU negotiation, shoot-day exceptions; decision recorded on the record.
3. Reassignment – startups / investors between RMs, IRMs, coordinators.
4. Policies – versioned with effective dates: screening pass mark, eligibility rules, fee schedule, working-day calendar (plus success-fee structure defaults – A-32).
5. Season setup – application window, fee schedule version, episodes, committee members (expert panel), legal templates.
6. Users & roles – add users, assign roles and departments.

**Approvals the super admin gives:** investor grade (IR) · revised or withdrawn commitment (IR) · MoU negotiation outcome (SR) · IRR final approval (Finance) · upfront fee exceptions and discounts (Finance) · extensions over 7 days, waivers, refunds, disputes (Finance) · mock shoot final readiness (Production) · episode edit (Production) · legal template versions (Legal) · promo assets (Marketing) · event budget (Community).
