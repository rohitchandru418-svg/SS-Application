# 99 – Assumptions, contradictions and gaps

Every place the spreadsheet is silent or contradicts itself. Each entry states the assumption the build uses. Entries marked **Decision needed** change behaviour the business should confirm; the rest are reasonable defaults that can be changed later, usually by editing a policy or a config value.

## Decisions needed from the business (answer these first)

| ID | Question | Assumption used until answered |
|---|---|---|
| A-29 | **Upfront fee schedule** – the Finance sheet says "fee schedule still to be supplied". What are the turnover bands, amounts, GST treatment? | `UPFRONT_FEE_SCHEDULE` policy with a placeholder 3-band schedule clearly labelled "PLACEHOLDER – not for production". |
| A-67 | **Screening 100-mark criteria** are not listed. | Policy-driven list; seed uses 5 placeholder criteria × 20 marks. |
| A-68 | **Analyst scoring scale** for the five dimensions is not given. | 1–5 per dimension, no weighting; policy-driven. |
| A-69 | **Investor eligibility rules** ("configurable") are not specified. | Rule engine with placeholder rules (e.g. agreements signed, KYC evidence present). |
| A-70 | **Grading dimensions** for L1–L4 are not listed, nor what each level permits ("permitted engagement and panel role"). | Policy with placeholder dimensions; level→permissions map stored in the same policy, default: all levels may be matched, only L1–L2 may lead on panel. |
| A-71 | **Application form fields** are not specified beyond profile areas. | Configurable form per season, seeded with profile sections plus pitch deck upload, ask amount, use of funds. |
| A-12 | **When does a founder get Community access?** Stage 19 is last but founders "request support" and community is also the lead engine. | Events and support requests open once the founder is *selected* (committee Proceed) – note: the state machine's `ALUMNI` state marks full completion; Community screens are enabled from `SELECTED`. Change via config flag `communityAccessFrom`. |
| A-14 | **Main-shoot signature deadline**: "Same day or 24 h – to confirm" (Founder and Production sheets). | 24 hours from shoot end; configurable. |
| A-15 | **What the founder sees after an analyst Hold or Reject.** Only "In progress" / "Fit check done" are defined. | Hold → "On hold"; Reject → "Not selected – Better luck next time – try again next season." (same wording as committee). |
| A-48 | **Contradiction – "On hold" verdict.** Founder sheet lists On hold as a per-investor virtual-pitch verdict; Investor and IR sheets do not offer it. | Investor form offers the five verdicts in the Investor sheet; IRM may additionally record "On hold" on the investor's behalf; founder sees it if recorded. |
| A-28 | **Contradiction – who approves fee extensions.** Finance sheet: super admin approves extensions. Super admin sheet: Finance lead up to 7 days, super admin over 7. SR sheet: "pass extension requests to Management". | Super admin sheet rule (≤ 7 days Finance lead, > 7 days super admin). |
| A-30 | **Episode edit final approval** is "proposed: super admin". | Super admin approves; switchable to Production head via config. |
| A-31 | **Marketing sheet says "Yellow rows = Proposed (needs approval)" but no rows are highlighted.** Which Marketing steps are still proposals? | All seven Marketing steps built as specified; flag in UI is not shown. |
| A-07 | **What investors may see about founders.** Not stated. | Founder names and startup business info; no founder email/phone. All contact goes through the team, pitches and the recorded deal thread. |
| A-37 | **When the founder first sees a matched investor's name.** Founder sheet: "matched investors shown by name"; not stated whether before or after the investor accepts. | After the investor accepts the match (avoids showing investors who decline). |
| A-41 | **Is the 7-day info-required window calendar or working days?** | Calendar days (MoU is the only place that says "working day"). Configurable. |
| A-66 | **Working-day calendar holidays** are not supplied. | Weekends only, plus a holiday list super admin can add to. |
| A-01 | **Technology stack** is not specified. | TypeScript, NestJS, Next.js, PostgreSQL/Prisma, Redis/BullMQ, S3 (AGENTS.md §2). Swap before P00 if you use another stack. |
| A-02 | **WhatsApp provider** not named. | Provider-agnostic adapter with dev stub; real provider (e.g. a WhatsApp Business API vendor) plugged in later. Template approval lead time to be planned. |
| A-03 | **Zoho Books integration details** (organisation, chart of accounts, invoice numbering, GST mapping, which system is master for invoice numbers). | Our system issues invoices and pushes them to Zoho Books; Zoho is the accounting ledger; sync failures queue for retry and appear on the Finance dashboard. |

## Contradictions resolved in the spec

| ID | Contradiction | Resolution |
|---|---|---|
| A-17 | Founder sheet: founder "picks slots" for virtual pitch; Investor sheet: "team-proposed schedule; investor approves slot"; Pitch Day explicitly "investor approves, then founder books". | Same rule for both rounds: team proposes → investor approves → founder books. |
| C-01 | SR sheet: "Production accepts" the handover pack; Production sheet: "IR approves; Production accepts". | Both steps: IR approves, then Production accepts. |
| C-02 | Investor stage 5 says "Review IRR, then accept or decline each match", but IRRs are listed as stage 6. | IRR is viewable on the match card from circulation (before acceptance); stage 6 is the ongoing IRR workspace (questions, documents, indicative amount). |
| C-03 | Founder stage 10 coordinates with "Management"; IR sheet says IR records the committee decision. | IR compiles the pack and records the decision taken by the committee (expert panel set in season setup). |
| C-04 | Investor committee results use "Rejected"; founder uses "Not selected". | Internal enum `REJECTED`; projected labels differ per persona. |
| C-05 | SR analyst metrics list Proceed / Hold / Reject, but analysts can also give Conditional proceed. | Metric includes Conditional proceed (A-63). |

## Other assumptions

| ID | Assumption |
|---|---|
| A-04 | All times stored UTC, shown in Asia/Kolkata. |
| A-05 | One founder login per startup (spreadsheet); co-founders are records without logins. Transfer of the login to another founder is a super admin action. |
| A-06 | An investor login may represent an individual or an entity; the authorised representative holds the login. |
| A-08 | Marketing, Legal and Community each work from a shared departmental queue (only Finance's is stated). |
| A-09 | Committee members have no logins; they receive a view-only pack export; IR records their decision and names the approvers. |
| A-10 | External DD advisors have no logins; their work is recorded by Legal/IR. |
| A-11 | The deal communication thread is not hosted in the app; the IRM records channel, opened time and reference. |
| A-13 | The founder's named contact is always the RM, even when another team owns the stage; the screen also names the team doing the work. |
| A-16 | Profile data is snapshotted into the application at submission. |
| A-18 | Founder can respond "I can't make this date" with a reason when confirming AV availability. |
| A-19 | Founder feedback is a 1–5 rating plus comments (Marketing dashboard shows "average rating"). |
| A-20 | Alumni / mentor directory shows only fields the member consented to share. |
| A-21 | Investor can "Request change" on announcement wording, returning it to Marketing. |
| A-22 | Season meter: Committed = confirmed deal commitments after main shoot (net of approved revisions/withdrawals); pre-shoot written commitments are shown separately as "proposed"; Available = allocation − committed. |
| A-23 | The interest form is public; submitting it sends an invite to register. Referred investors are created by IRM/Community and receive the same invite. |
| A-24 | Investor may request a change to the proposed season allocation instead of confirming; IRM re-proposes. |
| A-25 | IRR view-only enforced by server-rendered, watermarked page images; screenshots cannot be prevented and the watermark deters them. |
| A-26 | Default respond-by = 5 working days after circulation; default verdict due = 3 working days after the pitch; the system records "No response" after the due date. IRM can set other dates. |
| A-27 | Analyst evaluation overdue escalates to the SR team view and the super admin. |
| A-32 | Success-fee defaults (structure type, rate, cap) live in a policy; the actual terms come from each startup's signed MoU commercial schedule. |
| A-33 | Analyst assignment from the pool is automatic (least open load) with super admin reassignment. |
| A-34 | DD tasks are generated from a DD checklist template maintained by Legal. |
| A-35 | Founder sees that the Legal Q&A was held and a summary of answers. |
| A-36 | Founder stage 8 begins when the first investor accepts a match; before that the founder sees "Investor matching in progress". |
| A-38 | Founder sees the withdrawal reason as recorded for external sharing (separate field from internal notes). |
| A-39 | Founder sees announcement wording only after the investor has approved it. |
| A-40 | Investor questions and document requests about a startup go to the IRM, who routes them to SR (founder answers) or Finance (IRR); answers are posted back to the pairing. |
| A-42 | RM can move an application from On hold back to screening with a reason (e.g. founder replied late). |
| A-43 | A main shoot can end with no deal; the founder still goes to telecast; no deal track opens. |
| A-44 | Founder may decline a bootcamp invite (RM follows up; application stays at bootcamp). |
| A-45 | A founder-uploaded signed MoU is confirmed by the RM before it counts as Signed. |
| A-46 | If the super admin rejects a negotiation, the original MoU stands and its day-7 deadline continues; the RM may extend it once. |
| A-47 | MoU past day 7 without response raises an escalation to the super admin. |
| A-49 | Before any proof is uploaded the founder sees "Invoice issued – due <date>". |
| A-50 | A deal closes when verified deployed equals the (revised) commitment, or on approved withdrawal. |
| A-51 | Founder can confirm receipt before the investor reports the transfer; Finance still needs bank evidence. |
| A-52 | IRMs can read the analyst evaluation (to prepare the committee pack); investors never can. |
| A-53 | Production has no access to deal rooms. |
| A-54 | RMs can read (not edit) other RMs' startups via the team view. |
| A-55 | PDF redaction uses text-layer search for known PII strings; files with images/scans are flagged for manual review before the analyst can open them. |
| A-56 | RM and IRM auto-assignment uses least open workload among active staff. |
| A-57 | Virtual pitch meeting links come from a pluggable provider (Google Meet / Zoom / Teams to be chosen). |
| A-58 | Data hosted in India; compliance with India's DPDP Act (consent, purpose limitation, deletion on request for non-financial data). |
| A-59 | External users log in with email/phone OTP; internal users with password + TOTP MFA (SSO can replace this later). |
| A-60 | Form 16A reminders monthly until uploaded, plus at quarter-end. |
| A-61 | Internal users get in-app notifications and a daily email digest; urgent items (approvals, escalations) also by email immediately. |
| A-62 | On-set capture tolerates poor connectivity by queueing changes locally and syncing; conflicts resolved by last-writer with audit. |
| A-63 | SR analyst metrics include Conditional proceed. |
| A-64 | Analyst dashboard is not in the spreadsheet; a minimal queue dashboard is built. |
| A-65 | Founder sees DD document requests and agreement tasks, not the text of DD findings. |
| A-72 | Duplicate check keys: CIN, website domain, founder email, founder phone. |
| A-73 | MoUs are generated from the approved template with startup fields merged, then shared as PDF. |
| A-74 | IRR information checklist is a Finance-maintained template. |
| A-75 | IRR is authored outside the app and uploaded as PDF per version (an in-app editor can come later). |
| A-76 | Founders do not see their own IRR (not stated as shown to founders). |
| A-77 | Thesis fit in matching = tag overlap between investor thesis tags and startup tags. |
| A-78 | "5–6 matched startups" is read as the target per investor; the engine suggests up to 6 investors per startup and caps active matches per investor at 6 by default. |
| A-79 | "Startups they showed interest in" = pairings with verdict Ready to invest or Next stage, or any Pitch Day outcome other than Pass. |
| A-80 | "Next-season deal flow" = a preview list of next-season applicants that have reached screening Proceed, shown after the new season opens. |

## Out of scope (per spreadsheet or deferred)
- UI colours, typography, design system (supplied by the business).
- Outside law-firm restricted login (deferred in the Legal sheet).
- Partner revenue share (field present, off by default).
- Reach/view metrics for founder posts (explicitly excluded).
- Languages other than English.

## Added during build
_OpenHands appends new assumptions here, one row per assumption, with the phase and a short reason._

| ID | Phase | Assumption | Reason |
|---|---|---|---|
