# 12 – Dashboards and metrics

All metrics are computed from the shared database (SQL views or materialised views refreshed on relevant events; never manually maintained). Every metric tile is clickable and opens the filtered list behind it. Filters on every dashboard: season (default current), owner, date range.

## SR
- **My startups** (each RM, default landing): action queue sorted by due date and overdue; my startups by stage; my follow-ups; my numbers for each metric below.
- **Team view** (super admin default; RMs read-only): same metrics for the whole team, per-RM column (workload, overdue, conversion), stage ageing, bottlenecks; reassign (super admin only).

| Area | Counts |
|---|---|
| Intake | New applications, acknowledgements pending, awaiting RM assignment |
| Screening | Screened, waiting, Proceed / Information required / Hold / Reject, auto-held after 7 days |
| Bootcamp | Invites not sent, briefings not done, preparation complete |
| Analyst | Sent, decisions waiting, Proceed / Hold / Reject (plus Conditional proceed – A-63) |
| MoU | Shared, Legal Q&A done, signed, negotiating, discontinued, past day 7 |
| IRR | Requested, in progress, documents missing, approved, handed to IR, at risk of 2-week rule |
| Pitches | In virtual pitch, in Pitch Day, Golden Passes received |
| Committee | Approved, on hold, rejected |
| Upfront fee | % collected of fee determined, not collected, overdue |
| Shoots | AV / mock / main: done vs pending |
| Success fee | % collected, not collected, overdue |
| Promotion | Content posted vs pending, feedback received |
| Workload | Overdue actions per RM |

## IR
- **My investors** (each IRM): action queue; my investors with season meters; my pairings by stage; my deals by closure stage.
- **Team view** (super admin; IRMs read-only): whole team, per-IRM column, grade approvals waiting, commitment changes waiting, reassignment (super admin only).

| Area | Metric |
|---|---|
| Investors | Verified investors; agreements pending; pipeline sourced → verified → graded → active |
| Grades | Distribution L1–L4; approvals waiting; reviews due |
| Capital | Unallocated capital; per investor allocated vs committed vs deployed |
| Matching | Coverage; startups with fewer than 3 matches; acceptance / decline rate |
| Pitches | Unanswered pitches; verdict mix per round; average investor response time |
| Interest conversion | Golden Pass → written commitment → signed → deployed |
| Compliance | IRR with investors 2 weeks before shoot; thread opened within 48 h |
| Deals | Outstanding commitments; deals at risk; by closure stage with days stuck; revised commitments; withdrawals awaiting replacement |
| Workload | Overdue actions per IRM |

## Finance (one shared view with work queue)
| Area | Metric |
|---|---|
| Work queue | Everything waiting on Finance, by due date and overdue |
| IRR | Requested, accepted, documents missing, in review, awaiting super admin, approved, at risk of 2-week rule |
| Upfront fee | Determined vs collected vs outstanding; overdue by age (0–15, 15–30, 30+) from original due date; extensions; disputes; waivers |
| Receipts to check | Proofs awaiting verification (upfront + success) |
| Deployment | Committed vs investor-reported vs verified; tranches awaiting verification; reversals |
| Success fee | Forecast, due, invoiced, collected, outstanding; overdue; due but not invoiced |
| Reconciliation | Accounts not balanced; TDS certificates pending; GST entries |
| System | Zoho Books sync failures |

## Production
- **My shoots** (coordinator): my startups by shoot stage, shoot calendar, founder availability pending, signatures outstanding.
- **Production view** (head + super admin): all metrics, per-coordinator workload, readiness approvals waiting.

| Area | Metric |
|---|---|
| Pipeline | Paid startups awaiting AV; advance notices received, fee not yet paid |
| Handovers | Packs awaiting IR approval / Production acceptance |
| AV | Completion; assets uploaded vs pending |
| Mock | Readiness; approvals waiting |
| Documents | Missing documents; signatures past deadline |
| Episodes | Allocation; shoot calendar |
| Exceptions | By type |
| Founders | Availability confirmations pending |
| Content | Episodes in editing / awaiting approval; founder feedback received and actioned |

## Legal
MoU (Q&As due by day 4; negotiations open) · Due diligence (deals in DD; open findings by severity; days in DD) · Agreements (awaiting drafting / signature) · Conditions (pre-funding conditions outstanding; deals blocked by Legal).

## Marketing
Episodes (scheduled, aired, upcoming air dates) · Founders (notified vs pending) · Assets (awaiting approval, approved) · Posting (founder posting completion %) · Feedback (received, average rating, routed to Production) · Announcements (drafts awaiting investor approval; claims flagged where announced ≠ deployed).

## Community
Participation (active members; repeat attendance) · Partners (activity) · Referrals (qualified; funding linked to community) · Support (resolved vs open).

## Analyst
My queue: assigned, due in ≤ 2 working days, overdue; my submissions by recommendation (A-64).

## Management (super admin)
Conversion (application → selection) · Backlog (stage-wise backlog and ageing) · Investors (engagement and conversion) · Upfront fees (due, collected, overdue) · Show (shoot and telecast readiness) · Money (commitments, signed deals, verified deployment) · Success fees (due, invoiced, collected, overdue) · Community (activity, outcomes) · Exceptions (department-wise overdue actions and material exceptions) · Approvals (waiting and ageing vs 2-working-day deadline).

## Metric definitions to implement exactly
- **Committed** (investor meter): sum of confirmed deal commitments (after main shoot `DEAL_CONFIRMED`, net of approved revisions/withdrawals). Indicative amounts, analyst interest and Golden Passes are **not** commitments (A-22).
- **Deployed**: sum of `Tranche.verifiedAmount` minus reversals.
- **Available**: allocation − committed.
- **Fee determined** (upfront): approved fee amount; **collected**: verified receipts.
- **Five fee numbers** as defined in `04` §4.3.
- **Stage ageing**: now − entered-current-state timestamp (from audit/events).
- **Conversion rates**: computed per season cohort.
