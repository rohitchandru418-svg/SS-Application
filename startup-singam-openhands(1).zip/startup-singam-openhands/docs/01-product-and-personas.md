# 01 – Product and personas

## Product in one paragraph

Startup Singam is a season-based startup investment programme that ends in a televised show. Startups apply, are screened, prepared in a bootcamp, checked for investment fit, sign an MoU, get an Investment Readiness Report (IRR), are matched with verified investors, pitch virtually and at Pitch Day, are shortlisted by a committee, pay an upfront fee, are filmed (AV shoot, mock shoot, main shoot where deals are struck on set), are telecast and promoted, close their deals with each investor, receive funds tranche by tranche, pay a success fee on verified money, and join the alumni community. The application runs the whole lifecycle for two external personas (Founder, Investor) and nine internal personas, on one shared database.

Product-wide rules from the spreadsheet: English only; mobile-first founder portal; notifications by WhatsApp, email and in-app; one founder login per startup; one login per investor; investors pay no fees.

## Persona map

### External personas (log in to a portal)

| Persona | Portal | Count per entity | Purpose | Must never see |
|---|---|---|---|---|
| **Founder** (startup) | Founder portal, mobile-first | One login per startup (A-05) | Apply, respond to requests, sign and upload, pick slots, pay fees, post promotions, close deals, confirm funds, join community | Screening score, analyst scores / willingness / indicative amount, investor grade, internal notes, committee rejection reason, investor confidential remarks, fee calculation workings for success fee |
| **Investor** | Investor portal, responsive | One login per investor (individual or entity – A-06) | Register, profile, sign agreements, get verified, commit a season amount, review matches and IRRs, pitch verdicts, Pitch Day, committee results, commit on set, close deals, report transfers, approve announcements, community | Own grade (L1–L4), other investors' data, analyst evaluations, screening scores, other startups' IRRs not matched to them, founder contact details (A-07) |

### Internal personas (log in to the internal console)

| Persona | Department | How assigned | Owns | Default landing |
|---|---|---|---|---|
| **Relationship manager (RM)** | Startup Relations (SR) | Auto-assigned per application | Founder steps 1–7 (intake → IRR handover); view & follow-up on 8–11 | "My startups" action queue |
| **Analyst** | Analyst pool (separate persona) | Assigned from pool per startup | Investment fit evaluation and recommendation | "My queue" (single queue) |
| **Finance member** | Finance | Shared queue (same people do IRR, fees, verification, reconciliation) | IRR preparation, upfront fee, receipt verification, deployment verification, success fee, reconciliation, Zoho Books sync | Finance work queue |
| **Finance lead** | Finance | Role | Reviews IRRs, approves standard fees, reviews success fee invoices, approves extensions ≤ 7 days, closes reconciliation | Finance work queue + review items |
| **Legal member** | Legal (in-house) | Shared queue | Legal Q&A, MoU redraft, templates, due diligence, definitive agreements, pre-funding conditions | Legal work queue |
| **IR manager (IRM)** | Investor Relations (IR) | Auto-assigned per investor; one accountable IRM per deal | Investors end to end; matching; pitches; committee pack; pre-shoot panel; deal closure | "My investors" action queue |
| **Production coordinator** | Production & Show Ops | Assigned per startup | AV, mock and main shoot coordination, on-set capture, post-shoot signatures | "My shoots" |
| **Production head** | Production | Role | Episode allocation, editing review, feedback loop, oversight | Production view |
| **Marketing member** | Marketing & telecast | Shared queue (A-08) | Telecast schedule, promo assets, founder posting, post-telecast, feedback, public announcements | Marketing dashboard |
| **Community member** | Community & ecosystem | Relationship owner per member | Member records, events, referrals, founder support requests | Community dashboard |
| **Super admin** | Management (CEO, directors, managing partners) | Any one can approve; system records who | Approvals inbox, escalations, reassignment, policies, season setup, users and roles, final approvals listed in `04` § Super admin | Approvals inbox + Management dashboard |

### People with records but no login

| Who | Where they live | Notes |
|---|---|---|
| Co-founders | Startup record (founders list) | No login (A-05). Hidden from analysts. |
| Mentors, partners | Community member records | Spreadsheet: "mentors and partners have no logins". |
| Committee members (expert panel) | Season setup | IR records the committee decision (A-09). |
| External advisors (DD) | Named on deal DD tasks | No login; Legal/IR record their work (A-10). |
| Outside law firm | — | Restricted login deferred (spreadsheet). Not built. |
| Broadcaster | Telecast record | No login; Marketing records air date. |

## Key relationships between personas

- A **startup** is owned by one founder login, worked by one RM, one analyst (from pool), the Finance queue, a production coordinator, and – per investor – the IRM accountable for that pairing/deal.
- An **investor** is owned by one IRM. Each investor–startup **pairing** is its own record; after the main shoot each accepted investor–startup combination becomes a **deal** with one accountable IRM.
- **Super admin** sits over every department and is the approver for the exceptions listed in `04`.
- External personas never talk to each other inside the system. Founder ↔ investor contact happens in scheduled pitches, on set, and in the deal communication thread, which runs on email/WhatsApp and is only *recorded* in the system (A-11).

## Who sees whose work (high level)

```
          Founder portal                     Investor portal
               ▲  ▼                                ▲  ▼
   ┌───────────┴──┴───────── shared database ──────┴──┴───────────┐
   │ SR · Analyst · Finance · Legal · IR · Production · Marketing │
   │ Community · Super admin  (internal console)                   │
   └───────────────────────────────────────────────────────────────┘
 Projections decide what each viewer sees; nothing is copied.
```

Detailed field-level rules are in `08-permissions-and-visibility.md`.
