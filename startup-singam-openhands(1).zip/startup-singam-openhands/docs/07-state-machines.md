# 07 – State machines

Format: `FROM → TO` · **by** (role or SYSTEM) · guard · side effects (events). Any transition not listed is illegal. "Founder label" / "Investor label" show the projected external text where it differs.

## Application

| From → To | By | Guard | Events / effects |
|---|---|---|---|
| — → `DRAFT` | Founder | Season `OPEN`; no other non-terminal application for this startup in season | — |
| `DRAFT` → `SUBMITTED` | Founder | completeness = 100% (idea stage excludes financials); before window close | `application.submitted` → assign RM, acknowledgement, duplicate check, snapshot |
| `DRAFT` → `EXPIRED` | SYSTEM | season window closed | `application.expired` |
| `SUBMITTED` → `IN_SCREENING` | RM | assigned RM | — |
| `IN_SCREENING` → `INFO_REQUIRED` | RM | ≥ 1 InfoRequest item | dueAt = +7 days (A-41); notify founder |
| `INFO_REQUIRED` → `IN_SCREENING` | SYSTEM | all items answered | notify RM |
| `INFO_REQUIRED` → `ON_HOLD` | SYSTEM | dueAt passed | `screening.auto_held` (label "On hold") |
| `IN_SCREENING` → `ON_HOLD` / `REJECTED` / `SCREENING_PASSED` | RM | scorecard complete, reason given | notify founder with label |
| `ON_HOLD` → `IN_SCREENING` | RM | reason (A-42) | — |
| `SCREENING_PASSED` → `BOOTCAMP` | SYSTEM | on invite created | — |
| `BOOTCAMP` → `PREPARED` | RM | preparation complete (all briefings recorded, required action items done) | — |
| `PREPARED` → `WITH_ANALYST` | RM | — | `analyst.referral.created` (redacted) |
| `WITH_ANALYST` → `ANALYST_DONE` | SYSTEM | evaluation submitted | founder label "Fit check done" / On hold / Not selected |
| `ANALYST_DONE` → `MOU` | RM | recommendation ∈ {PROCEED, CONDITIONAL_PROCEED} | create `Mou`; if conditional → SR ActionItem `BLOCKS_IRR_HANDOVER` |
| `ANALYST_DONE` → `ON_HOLD` / `REJECTED` | SYSTEM | recommendation HOLD / REJECT | SR cannot override REJECT |
| `MOU` → `IRR` | SYSTEM | MoU `SIGNED` | `irr.requested` |
| `MOU` → `DISCONTINUED` | RM | MoU `DISCONTINUED` | — |
| `IRR` → `MATCHING` | SYSTEM | IRR handover accepted by IR | — |
| `MATCHING` → `PITCH_DAY` | SYSTEM | ≥ 1 pairing with NEXT_STAGE or READY_TO_INVEST and Pitch Day scheduled | — |
| `PITCH_DAY` → `COMMITTEE` | IRM | Pitch Day done | — |
| `COMMITTEE` → `SELECTED` / `ON_HOLD` / `REJECTED` | IRM (records) | decision with approver + date | on SELECTED: `committee.decision.proceed` |
| `SELECTED` → `FEE` | SYSTEM | fee request created | — |
| `FEE` → `PRODUCTION` | SYSTEM | upfront fee fully verified | `fee.upfront.fully_verified` |
| `PRODUCTION` → `POST_SHOOT` | SYSTEM | main shoot deal(s) confirmed (or zero deals – A-43) | splits into telecast + deal tracks |
| `POST_SHOOT` → `ALUMNI` | SYSTEM | telecast done **and** every deal closed/withdrawn **and** account closed | alumni badge (Community screens already open from `SELECTED` – A-12) |

## Screening verdict (on scorecard): `PROCEED` · `INFO_REQUIRED` · `HOLD` · `REJECT`. Founder labels: Proceed / Information required / On hold / Not selected.

## Bootcamp participation
`INVITED → ACCEPTED → ATTENDING → PREPARATION_COMPLETE`; `INVITED → DECLINED` (A-44). Preparation complete only by RM.

## Analyst referral
`QUEUED → ASSIGNED (SYSTEM from pool) → IN_PROGRESS → SUBMITTED`. `ASSIGNED/IN_PROGRESS` past 5 working days → flag `OVERDUE` + `Escalation` (A-27). Recommendation enum: `PROCEED`, `CONDITIONAL_PROCEED`, `HOLD`, `REJECT`.

## MoU

| From → To | By | Effects |
|---|---|---|
| — → `SHARED` | RM | clockStartedAt = now; legalQaDueAt = +4 working days; signDueAt = +7 working days |
| `SHARED` → `QA_HELD` | Legal | Q&A logged |
| `SHARED`/`QA_HELD` → `SIGNED` | RM (records founder upload) or Founder upload + RM confirm (A-45) | signed copy, commercial schedule, exceptions, signature date required |
| `SHARED`/`QA_HELD` → `NEGOTIATING` | Founder or RM | reason; `Approval(MOU_NEGOTIATION)` to super admin; escalation |
| `NEGOTIATING` → `REDRAFTING` | Super admin approves terms | Legal task: MoU v2 |
| `NEGOTIATING` → `SHARED` | Super admin rejects negotiation | original version stays; clock continues (A-46) |
| `REDRAFTING` → `SHARED` | RM shares v2 | **clock restarts** |
| any open → `DISCONTINUED` | Founder or RM | founder email + reason |
| `SHARED` past signDueAt | SYSTEM | flag "past day 7", escalation to super admin (A-47) |

## IRR
`REQUESTED → ACCEPTED (Finance) → GATHERING → IN_PREPARATION → IN_REVIEW (Finance lead) → AWAITING_APPROVAL (super admin) → APPROVED → HANDED_OVER (IR accepts)`. `IN_REVIEW`/`AWAITING_APPROVAL` → `IN_PREPARATION` on rejection with reason (new version). `APPROVED → HANDED_OVER` guarded by: no open `BLOCKS_IRR_HANDOVER` action items. Every version kept.

## Investor

| From → To | By | Guard |
|---|---|---|
| — → `LEAD` | Public form / Community referral / IRM | dedupe by email/phone/PAN |
| `LEAD` → `REGISTERED` | Investor | account created |
| `REGISTERED` → `PROFILE_COMPLETE` | Investor | required profile fields |
| `PROFILE_COMPLETE` → `VERIFYING` | IRM | — |
| `VERIFYING` → `MORE_INFO_NEEDED` → `VERIFYING` | IRM / Investor | items |
| `VERIFYING` → `VERIFIED` | IRM | eligibility policy passed; PARTICIPATION + NDA `SIGNED` |
| `VERIFIED` → `GRADE_PENDING_APPROVAL` | IRM | grade proposed with evidence |
| `GRADE_PENDING_APPROVAL` → `GRADED` | Super admin | — |
| `GRADED` → `ALLOCATION_PROPOSED` | IRM | allocation + max per startup |
| `ALLOCATION_PROPOSED` → `ACTIVE` | Investor confirms | — |
| any → `INACTIVE` | IRM / super admin | reason |

Investor labels: steps before VERIFIED show "In progress" or "More information needed"; VERIFIED and later show "Verified". Grade states never projected.

## Pairing

| From → To | By | Effects |
|---|---|---|
| — → `SUGGESTED` | SYSTEM (matching) | — |
| `SUGGESTED` → `CIRCULATED` | IRM approves | IRR version shared; respondByAt set |
| `SUGGESTED` → `DISCARDED` | IRM | — |
| `CIRCULATED` → `ACCEPTED` / `DECLINED` | Investor (or IRM on behalf) | decline reason |
| `CIRCULATED` past respondByAt | SYSTEM | `NO_RESPONSE` (A-26) |
| `ACCEPTED` → `VIRTUAL_PITCH` | SYSTEM when slot booked | — |
| `VIRTUAL_PITCH` → verdict states | Investor or IRM on behalf | `READY_TO_INVEST`, `NEXT_STAGE`, `INFO_REQUESTED`, `ON_HOLD` (A-48), `PASS`, `NO_RESPONSE` (SYSTEM after verdict due) |
| `INFO_REQUESTED` → `VIRTUAL_PITCH` | SYSTEM when answered | verdict re-opened |
| `NEXT_STAGE`/`READY_TO_INVEST` → `PITCH_DAY` | IRM maps | — |
| `PITCH_DAY` → `GOLDEN_PASS` / `WRITTEN_COMMITMENT` / `NO_RESPONSE` / `PASS` | IRM records | — |
| any active → `WITHDRAWN` | Investor / IRM | reason |

## Committee decision: `PROCEED`, `ON_HOLD`, `REJECTED`. Founder label for REJECTED: "Not selected" + fixed text. Investor label: "Rejected".

## Upfront fee

`REQUESTED (SYSTEM, clock 15 d) → TURNOVER_VERIFIED → CALCULATED → PENDING_APPROVAL → APPROVED → INVOICED → {PROOF_UPLOADED → (VERIFIED_PART → PART_PAID | VERIFIED_FULL → PAID) | OVERDUE} `.
- `INVOICED`/`PART_PAID` past dueAt → `OVERDUE` (SYSTEM).
- Extension: `Extension.REQUESTED → APPROVED/REJECTED` (Finance lead if ≤ 7 days, super admin if > 7 days); on approve: invoice.dueAt = new date, originalDueAt kept, fee label "Extension approved".
- `PROOF_UPLOADED` never becomes paid without a `Receipt` matched to bank (screenshot rule).
- `PAID` → event `fee.upfront.fully_verified`.
- Founder labels: Proof uploaded – verifying / Paid / Part paid / Overdue / Extension approved (and "Invoice issued" before proof – A-49).

## Handover pack
`ASSEMBLED (SYSTEM) → IR_APPROVED → PRODUCTION_ACCEPTED`. Rejection by IR → `NEEDS_FIX` with reason → re-assembled.

## Shoots
- AV: `PLANNED → SCHEDULED → FOUNDER_CONFIRMED → COMPLETED (assets saved)`; `RESCHEDULED`.
- Mock: `SCHEDULED → IN_PROGRESS → READINESS_SUBMITTED → READINESS_APPROVED (super admin) | CHANGES_REQUESTED`.
- Main: `SCHEDULED → ON_SET → CAPTURED → DEAL_CONFIRMED | NO_DEAL`, with exceptions logged; `SHOOT_FILE_COMPLETE` once all signing events signed and uploaded.
- Episode edit: `EDITING → HEAD_REVIEWED → APPROVED (super admin) → HANDED_TO_MARKETING`.

## Deal

`CONFIRMED (SYSTEM from on-set capture) → THREAD_OPEN (IRM records thread; due 48 h) → TERM_SHEET → DUE_DILIGENCE → AGREEMENTS → CONDITIONS → FUNDING → CLOSED`.
- Any state → `REVISION_PENDING` / `WITHDRAWAL_PENDING` (reason; super admin approval) → back to previous state with new amount / → `WITHDRAWN` (replacement search opens: `ReplacementSearch` linked).
- `DUE_DILIGENCE → AGREEMENTS` guard: all HIGH/CRITICAL findings resolved; IR confirms DD complete.
- `CONDITIONS → FUNDING` guard: all pre-funding conditions met; IR confirms.
- `FUNDING → CLOSED` guard: verified deployed = committed (net of approved revisions) (A-50).

## Tranche
`SCHEDULED → INVESTOR_REPORTED (investor or IRM) → FOUNDER_CONFIRMED → VERIFIED (Finance, bank evidence)`. Founder may confirm before investor reports (A-51). `VERIFIED → REVERSED_PARTIAL / REVERSED` via `Reversal`. `VERIFIED` emits `tranche.verified`.

## Success fee
`CALCULATED (SYSTEM task, Finance completes) → IN_REVIEW (Finance lead) → INVOICED (one per tranche) → PROOF_UPLOADED → PAID_TDS_PENDING → PAID` ; `OVERDUE` past due; reversal after invoice → credit note.

## Startup account
`OPEN → BALANCED (system check) → CLOSED (Finance lead, requires all TDS certificates)`.

## Approval
`PENDING (dueAt = +2 working days) → APPROVED | REJECTED (reason)`; `PENDING` past dueAt is shown as overdue (no auto-decision).

## Announcement
`DRAFT → AWAITING_INVESTOR → APPROVED → PUBLISHED`; `AWAITING_INVESTOR → CHANGES_REQUESTED → DRAFT`.

## Promo asset
`DRAFT → AWAITING_APPROVAL (super admin/CEO) → APPROVED → SHARED_WITH_FOUNDER`; `CHANGES_REQUESTED`.

## Support request
`OPEN → IN_PROGRESS → RESOLVED → (founder feedback) CLOSED`.

## Referral
`INTERACTION → REFERRAL → LEAD → QUALIFIED → ENGAGED → FUNDED | OTHER_OUTCOME`.
