# 11 – UX principles and screen inventory

Visual design (colours, typography, spacing, iconography, component styling) is supplied by the business's existing design system. This document defines **structure, content, states and behaviour** only.

## 11.1 Design-system slot

- `packages/ui` exports the components below with stable props. P00 ships unstyled, accessible placeholders (semantic HTML + ARIA). The business replaces the implementation (or re-exports from their design-system package) without changing call sites.
- Required components: `AppShell`, `TopBar`, `SideNav`, `BottomNav` (founder mobile), `Page`, `PageHeader`, `Card`, `NextStepCard`, `Timeline` (supports parallel lanes), `StatusChip` (always has text; `tone` prop: neutral/info/success/warning/danger), `Countdown` (shows "Due in 3 days" / "Overdue by 2 days"), `ProgressMeter`, `SeasonMeter`, `DataTable` (sort, filter, column picker, bulk select, sticky header), `ActionQueue`, `KpiTile`, `Tabs`, `Drawer`, `Modal`, `Form`, `Field`, `TextInput`, `TextArea`, `Select`, `MultiSelect`, `DatePicker`, `MoneyInput` (INR, paise under the hood), `FileUpload` (drag-drop, camera on mobile, resumable, progress), `DocumentViewer` (watermark + no-download mode), `RequestItem` (see 11.3), `EmptyState`, `Skeleton`, `Toast`, `Banner`, `Avatar`, `Stepper`, `Checklist`, `ApprovalCard`, `HistoryList`, `CommentThread`.
- Theme tokens are read from CSS variables the design system defines; components must not hard-code colours or font sizes.

## 11.2 Global UX principles

1. **Next step first.** Every external home screen starts with a `NextStepCard`: what is needed, by when, one primary button, who is helping. Every internal landing screen is an action queue sorted by due date with overdue first.
2. **One request pattern.** Every "the team needs something from you" item – screening info, IRR query, DD request, verification query, bootcamp action item, readiness checklist item, investor question – uses `RequestItem`.
3. **Live and consistent.** Screens update in place when the shared record changes (see `09` §9.4). Show a subtle "Updated just now" marker on changed items.
4. **No dead ends.** Every negative or waiting state tells the user what happens next (e.g. "Not selected" → "Keep your profile updated for next season").
5. **Never leak.** External screens never show internal values; label mappings in `02`/`03`.
6. **Deadlines are explicit.** Countdowns on every item with a due date; past-due switches to "Overdue".
7. **Mobile-first founder portal**: single column, bottom navigation (Home, Journey, Requests, Documents, Profile), large touch targets, camera upload.
8. **Forms**: autosave, save-and-resume, inline validation with Zod messages, never lose input on network errors.
9. **Accessibility**: WCAG 2.2 AA; status never colour-only; focus returns to triggering element after modal; live regions announce realtime changes politely.
10. **Empty, loading and error states** for every list and card.

## 11.3 `RequestItem` component contract

Props: `title` (shown word for word), `requestedBy` (team name; person name for internal viewers), `dueAt`, `status` (`OPEN`, `SUBMITTED`, `ACCEPTED`, `RE_REQUESTED`, `CLOSED`), `responseType` (`TEXT`, `FILE`, `BOTH`), `history`. External view: reply box/upload, "Submit". Internal view: response, Accept / Re-request (with reason), internal note.

## 11.4 Founder portal screens

| Route | Screen | Key content |
|---|---|---|
| `/f` | Home | NextStepCard, timeline summary, updates feed |
| `/f/journey` | Journey | Full timeline 0–19, parallel lanes after 14, per-investor deal rows |
| `/f/requests` | Requests | All open RequestItems across stages, grouped by due date |
| `/f/profile` | Profile | Company, founders, sector/stage, financials, documents |
| `/f/application` | Application | Section form, completeness meter, missing items, submit |
| `/f/bootcamp` | Bootcamp | Invite, sessions, action items |
| `/f/mou` | MoU | Versions, Q&A date, countdown, three responses |
| `/f/investors` | Investors | Matched investor cards, slots, verdicts, Pitch Day |
| `/f/selection` | Final selection | Result |
| `/f/fee` | Upfront fee | Amount, basis, invoice, bank details, proof upload, extension |
| `/f/shoots` | Shoots | AV, mock checklist, main shoot summary, SDAL upload |
| `/f/telecast` | Telecast | Air date, assets, posting tasks, feedback |
| `/f/deals` + `/f/deals/:investor` | Deals | Deal cards, milestones, DD, agreements |
| `/f/funds` | Funds | Committed/received/pending per investor, tranche confirmation |
| `/f/success-fee` | Success fee | Invoices, proof + TDS, Form 16A |
| `/f/community` | Community | Events, support requests |
| `/f/notifications` | Notifications | In-app list, preferences |

## 11.5 Investor portal screens

| Route | Screen |
|---|---|
| `/interest` (public) | Express interest form |
| `/i` | Home with season meter + NextStepCard |
| `/i/profile` | Profile wizard |
| `/i/agreements` | Participation agreement, NDA |
| `/i/verification` | Verification status + queries |
| `/i/season` | Season commitment confirm |
| `/i/matches` + `/i/matches/:pairing` | Match cards, IRR viewer, questions, indicative amount, accept/decline |
| `/i/pitches` | Virtual pitch slots, minutes, verdicts |
| `/i/pitch-day` | Pitch Day slots, information memoranda, outcomes |
| `/i/results` | Committee results |
| `/i/shoot` | Pre-shoot confirmation, briefing, main shoot summary |
| `/i/deals` + `/i/deals/:deal` | Deal rooms |
| `/i/transfers` | Tranches, mark sent |
| `/i/announcements` | Approve wording |
| `/i/community` | Events, refer an investor |

## 11.6 Internal console screens

Shared: left nav by department (shown per role), global search (startup, investor, person – respects permissions and redaction), notifications, approvals badge.

| Area | Screens |
|---|---|
| SR | My startups (action queue), Team view, Application review (scorecard side-by-side with application), Info-required composer, Bootcamp batches (bulk attendance), Send to analyst, Analyst decision review, MoU desk, IRR request & follow-up, Lifecycle view, Startup 360 |
| Analyst | My queue, Evaluation workspace (redacted application + documents, scoring form, question-to-SR composer) |
| Finance | Work queue, IRR workspace (query composer, versions, submit for review/approval), Upfront fee desk, Receipts to check, Deployment verification, Success fee desk, Reconciliation ledger, Zoho sync status |
| Legal | Work queue, MoU Q&A log, Negotiation review & v2, Templates, DD board per deal (tasks + findings by severity), Agreements, Pre-funding conditions |
| IR | My investors, Team view, Investor record (profile, verification, grade proposal, allocation), Matching board (suggestions with factor breakdown, approve circulation), Pairing record, Pitch scheduler (virtual + Pitch Day), Verdict recorder (on behalf), Golden Pass / commitments, Committee pack builder + decision recorder, Pre-shoot panel builder, Deal room, Fund follow-up, Investor 360 |
| Production | My shoots, Production view, Planning list (advance notices), Handover packs, AV planner, Episode allocation (calendar), Signing events, Mock readiness, On-set capture (tablet-friendly, works with intermittent connectivity – A-62), Exceptions log, Post-shoot signatures, Editing & approvals, Feedback actions |
| Marketing | Dashboard, Telecast schedule, Promo assets, Founder posting tracker, Feedback, Announcements |
| Community | Dashboard, Members (person 360 with roles), Events, Referrals chain, Support requests |
| Super admin | Approvals inbox, Escalations, Management dashboard, Season setup wizard, Policies (versions + effective dates), Templates approval, Users & roles, Reassignment tool, Audit log |

### Startup 360 (internal)
Header: startup name, season, current internal stage, RM, coordinator, accountable IRMs. Tabs: Overview (lifecycle tracks: Selection, Production, Investment, Finance, Marketing, each with status and blockers), Application, Screening, Bootcamp, Analyst, MoU, IRR, Investors (pairings), Committee, Fees, Production, Deals, Funds, Marketing, Community, Documents, Notes, History. Tabs and fields shown per viewer permissions.

### Investor 360 (internal)
Season meter, profile, verification, grade (IR/super admin only), allocation, pairings by stage, deals and tranches, announcements awaiting approval, notes, history.

## 11.7 Internal UX improvements
- Default landing is "what needs me today"; zero-state congratulates and links to the team view.
- Bulk actions where volume is high (bootcamp attendance, sending invites, circulating IRRs to several matched investors).
- Side-by-side layouts for review tasks (application vs scorecard, IRR vs queries, proof vs invoice vs bank line).
- Keyboard shortcuts in queues (j/k to move, Enter to open, a to approve in approvals inbox).
- "Waiting on" indicator on every record: Founder / Investor / <Department> / Approval, so nobody has to ask who holds the ball.
