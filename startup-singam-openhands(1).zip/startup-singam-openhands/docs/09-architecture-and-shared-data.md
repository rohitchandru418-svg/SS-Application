# 09 – Architecture and the shared data source

## 9.1 Components

```
 Browser (founder · investor · internal)
        │  HTTPS (REST + SSE)
        ▼
 apps/web (Next.js)  ──calls──►  apps/api (NestJS)
                                   │  commands (packages/domain)
                                   ▼
                            PostgreSQL  ◄── single source of truth
                                   │  outbox table (same transaction)
                                   ▼
                     apps/worker (BullMQ consumers + schedulers)
                       ├─ notification consumer → email / WhatsApp / in-app
                       ├─ automation consumer → automatic records (fee request, handover pack, success-fee task…)
                       ├─ realtime publisher → Redis pub/sub → API SSE hub
                       ├─ deadline scheduler → auto transitions, overdue flags, escalations, reminders
                       └─ integrations → Zoho Books, file scanning, redaction
```

## 9.2 Shared data, no copies

- Founder portal, investor portal and internal console call the **same API** over the **same tables**. There is no "external database", no sync job between internal and external, and no duplicated status columns. The founder's "stage" is computed from the application's state by the founder projector; the investor's "stage" from the investor/pairing/deal states.
- When a fact belongs to both sides (e.g. a pitch slot, a verdict, a tranche), it is one row. Each side's writable fields are defined by permissions (e.g. investor writes `investorApprovedAt`, founder writes `founderBookedAt`).
- Documents are one `File` row; who can see it is decided by its classification and the record it hangs from.
- Snapshots exist only where the business needs immutability: application snapshot on submit, handover pack contents, IRR versions, MoU versions, invoice data. These are versioned records, not sync copies.

## 9.3 Command → event → effects

1. Client sends a command (e.g. `POST /screening/{id}/verdict`).
2. API resolves viewer, runs `can()`, loads aggregate, applies state-machine transition, writes changes + `AuditLog` + `OutboxEvent`s in **one DB transaction**.
3. Worker polls/listens to the outbox (`LISTEN/NOTIFY` + polling fallback), publishes each event once (idempotency key = event id), marks `publishedAt`.
4. Consumers react. Each consumer is idempotent and records processed event ids.

### Event naming
`<aggregate>.<fact>` in past tense, e.g. `application.submitted`, `screening.verdict_recorded`, `committee.decision_recorded`, `fee.upfront.fully_verified`, `tranche.verified`. Payload: ids + the minimum facts; consumers re-read the DB.

### Automatic effects catalogue (must be implemented exactly)

| Event | Automatic effect |
|---|---|
| `application.submitted` | Assign RM (load-balanced among active RMs – A-56); send acknowledgement; run duplicate check (same CIN / domain / founder email / phone across seasons → link `duplicateOf`); snapshot |
| `screening.verdict_recorded(INFO_REQUIRED)` | Create InfoRequest items; schedule auto-hold at +7 days |
| `bootcamp.preparation_completed` | Enable "Send to analyst" |
| `analyst.referral.created` | Assign analyst from pool (least loaded); schedule 5-working-day due |
| `analyst.evaluation.submitted` | Notify RM; founder label update; if CONDITIONAL → SR action item blocking IRR handover |
| `mou.shared` | Compute day 4 / day 7 with working-day calendar; notify founder + Legal |
| `mou.negotiation_requested` | Approval to super admin; escalation record; notify Legal |
| `mou.signed` | Create IRR request; alert Finance |
| `irr.approved` | Notify IR to accept |
| `irr.handover_accepted` | Run matching suggestions for the startup |
| `committee.decision_recorded(PROCEED)` | Create upfront fee request (15-day clock); Production advance notice; inform SR; notify founder & interested investors |
| `fee.upfront.fully_verified` | Assemble handover pack; request IR approval |
| `handover.accepted` | Enable AV booking |
| `episode.allocated` | Schedule 2-week IRR-rule check for each panel investor |
| `mainshoot.deal_confirmed` | Create `Deal` per accepted investor; schedule 48 h thread check; create DD task list from template; notify IRM, Legal, founder, investor |
| `deal.commitment_change_requested` | Approval to super admin |
| `deal.withdrawn` | Open replacement-investor search; notify founder |
| `tranche.verified` | Update season meter; create success-fee calculation task; update deal funding status |
| `tranche.reversed` | Reduce deployed and fee base; if success fee invoiced → credit note task |
| `invoice.issued` | Sync to Zoho Books; notify founder |
| `episode.approved` | Notify Marketing |
| `telecast.scheduled` | Notify founder of air date + promotion requirements |
| `announcement.drafted` | Request investor approval |
| `feedback.submitted` | Route to Production (and Marketing) |
| `referral.created` | Link to existing record (dedupe) or create lead |

## 9.4 Realtime propagation (internal ↔ external)

- Every resource has a **resource key**, e.g. `application:{id}`, `pairing:{id}`, `investor:{id}:meter`, `queue:user:{userId}`.
- The realtime publisher maps each event to the resource keys it changes and to the **users allowed to see those resources** (via the same scope rules as Layer 2). It publishes `{ keys: [...] }` to `user:{userId}` channels. No payload data is pushed – only invalidation keys – so a push can never leak a field.
- Web clients open one SSE connection (`GET /realtime/stream`). On a message, TanStack Query invalidates queries tagged with those keys and refetches through the normal permission-checked API.
- Target latency: < 2 s from commit to visible update. Reconnect with `Last-Event-ID`; on reconnect gap, invalidate everything for the current screen.
- Action queues (`queue:user:*`) are invalidated whenever a deadline-bearing record assigned to that user changes.

## 9.5 Concurrency and integrity

- Optimistic locking (`version`) on every aggregate; on conflict the UI shows "This was just updated by <name>" and reloads.
- Transitions re-check guards inside the transaction.
- Unique constraints: one active application per startup per season; one pairing per investor × application; one invoice per verified tranche; one deal per investor × application.

## 9.6 Files

- Upload via presigned PUT; API registers the file and triggers virus scan; the file is unusable until `scanStatus = CLEAN`.
- Download via short-lived presigned GET issued only after `can(viewer,'read',file)`.
- IRR viewer (investor): render pages server-side to images with a per-viewer watermark; never issue the original file to investors; disable download/print in the viewer; log `IrrViewLog`.
- Analyst: redacted variants only.

## 9.7 Audit and history

- `AuditLog` for every command (before/after diff, reason, on-behalf).
- Every record page in the internal console has a "History" tab built from audit + events.
- External users see their own activity history (what they submitted and when).

## 9.8 Integrations (adapters with dev stubs)

| Integration | Interface | Dev stub |
|---|---|---|
| Email | `EmailSender.send(to, templateKey, data)` | Mailpit |
| WhatsApp | `WhatsAppSender.send(phone, templateKey, data)` – template-based (A-02) | Logs to console + stores in Notification table |
| Zoho Books | `AccountingAdapter.createInvoice / recordPayment / createCreditNote / getStatus` | In-memory store; sync failures surfaced on Finance dashboard |
| Video meetings | `MeetingLinkProvider.create(slot)` (A-57) | Returns placeholder URL |
| Virus scan | `FileScanner.scan(file)` | Always clean |
| e-signature | Not used – documents are signed on paper/offline and uploaded (spreadsheet) | — |

## 9.9 Non-functional

- Hosting region India (A-58); backups daily with point-in-time recovery.
- Auth: email or phone OTP for external users; email + password + TOTP MFA for internal users (A-59). Session timeout internal 12 h, external 30 days with refresh.
- Rate limiting on auth and public interest form; CAPTCHA on the public form.
- Logging with request ids; no PII in logs.
- Performance: action queue pages < 500 ms p95 with 5 000 startups and 1 000 investors per season.
