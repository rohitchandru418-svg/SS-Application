# 03 – Investor journey (external)

One login per investor. Grade (L1–L4) is internal and never shown. A **season meter** sits on every investor screen: season allocation · committed · deployed · available. No fees for investors. The deal communication thread runs on email/WhatsApp; the system records when it was opened.

| # | Investor sees | Internal stage | Shown to investor | Investor action | Deadline shown | Team |
|---|---|---|---|---|---|---|
| 0 | Express interest | Sourcing | Short interest form; referred by (if any) | Register and log in | — | IR |
| 1 | Investor profile | Sourcing record | Category and investing entity, decision-maker, authorised representative, sectors, stages, geography, thesis, ticket size, portfolio, availability, expected decision timeline | Complete profile | — | IR |
| 2 | Agreements | Participation & confidentiality documents | Participation agreement and NDA (no MoU) with status | Sign and upload both | Sign-by date | IR, Legal |
| 3 | Verification | Verification & eligibility | In progress / More information needed (exact items) / Verified. Grade NOT shown. | Answer verification queries, upload evidence | Reply-by date | IR |
| 4 | Season commitment | Proposed season allocation | Season amount and maximum per startup, with season meter | Confirm season amount and per-startup maximum | — | IR |
| 5 | Your matches | Matching | 5–6 matched startups with match % (sector, stage, ticket, geography) | Review IRR, then accept or decline each match | Respond-by date | IR |
| 6 | Investment Readiness Reports | IRR shared | IRR per matched startup, view in system only (no download), with version and date shared | Read, ask questions, request documents, give indicative amount | — | IR |
| 7 | Virtual pitches | Virtual pitch | Team-proposed schedule per startup (5 min pitch + 5 min Q&A) | Approve slot, attend, acknowledge minutes. Verdict per startup: Ready to invest / Next stage / Information requested / Pass / No response. "Ready to invest" opens form: amount, valuation range, instrument, conditions – marked indicative | Verdict due date | IR |
| 8 | Pitch Day | Pitch Day & Golden Pass | Team-proposed 1:1 slots (investor approves, then founder books), information memorandum. Golden Pass / written commitment recorded by the team after it is issued. | Approve slots, attend, acknowledge minutes; follow-on interest | Pitch Day date | IR |
| 9 | Committee results | Final Shortlisting Committee | For each startup they showed interest in: Proceed / On hold / Rejected | — | — | Management |
| 10 | Pre-shoot confirmation | Pre-shoot panel | Episode and shoot date, IRR received (2-week rule), written proposed commitment, valuation boundaries, decision parameters, production briefing, documents needed | Confirm commitment in writing, acknowledge briefing | 2 weeks before shoot | IR, Production |
| 11 | Main shoot | Main shoot | Offers, accepted deal, lead / co-investor split, conditions, Investment Commitment Letter given, founder's Acceptance Letter received | Sign Investment Commitment Letter | Signing deadline | Production, IR |
| 12 | Deal room (one per startup) | Post-shoot closure | Communication thread opened (48 h countdown, held on email/WhatsApp), term sheet, DD progress (IR, Finance, Legal, external advisors), findings resolved, agreements, pre-funding conditions, expected date per milestone; revisions and withdrawals need a reason | Share term sheet, respond to DD queries, sign agreements; request revision / withdrawal with reason | 48 h, then milestone dates | IR, Legal, Finance, advisors |
| 13 | Fund transfers | Deployment tracking | Per tranche: scheduled amount and date, "You reported ₹X", "Startup confirmed receipt", Verified, remaining to deploy | Mark tranche sent with UTR and proof | Tranche dates | IR, Finance |
| 14 | Public announcement | Marketing | Proposed public wording (announced vs committed vs deployed) | Approve wording (or request change – A-21) | Before publication | Marketing |
| 15 | Community | Community | Investor sessions, events, next-season deal flow | Join events, refer other investors | — | Community |

## Investor screen behaviour

### Persistent header: season meter
`Allocation ₹A · Committed ₹C · Deployed ₹D · Available ₹(A − C)` (A-22 defines "available"). Updates live when IR records an allocation, an indicative/written commitment becomes a confirmed commitment, or Finance verifies a tranche. Shown on every investor screen once stage 4 is confirmed; before that the slot shows "Season commitment not set yet".

### Home ("Your season")
- Next step card (same pattern as founder): what is needed, deadline, button, IRM name.
- Sections: Matches awaiting your response · Pitches to schedule / verdicts due · Pitch Day · Deals in progress · Transfers due · Announcements awaiting approval.

### Onboarding (0–4)
- Express interest form (public page, no login) → creates an investor lead and an invite to register (A-23). Profile wizard with save-and-resume. Agreements: two document cards (Participation agreement, NDA) with download → sign → upload; status. Verification: list of exact queries with reply/upload. Season commitment: show the proposed amounts recorded by IR, investor confirms (or asks to change – A-24).

### Matches (5–6)
- Match cards: startup name, sector, stage, ask, geography, match % with the breakdown of matching factors visible to the investor (sector, stage, ticket, geography only; grade/thesis weighting stays internal), respond-by date, IRR button.
- IRR viewer: in-browser only, no download, no print stylesheet, per-viewer watermark (investor name + timestamp), version and date shared; every open is logged (A-25).
- From the IRR: Ask a question, Request a document, Give indicative amount. Accept / Decline match (decline asks for a reason).

### Pitches (7–8)
- Slot approval for team-proposed slots; joining details; after the pitch, "Acknowledge minutes". Verdict form with the five options; "Ready to invest" expands to amount, valuation range, instrument, conditions, all labelled **Indicative**. Overdue verdict shows "Verdict due" and, after the due date, the system records "No response" (A-26).
- Pitch Day: approve 1:1 slots, information memorandum (view only), follow-on interest. Golden Pass and written commitment appear once recorded by the team.

### Committee results (9)
- List of startups the investor showed interest in, with Proceed / On hold / Rejected.

### Pre-shoot & main shoot (10–11)
- Episode and shoot date, IRR received confirmation, proposed commitment, valuation boundaries, decision parameters, production briefing (acknowledge), documents needed, "Confirm commitment in writing". Main shoot summary and the Investment Commitment Letter (signed on paper on set, uploaded by Production or the investor).

### Deal room (12)
- One per startup. Milestone tracker with expected dates; 48 h thread countdown and "Thread opened at …"; term sheet upload; DD queries with replies; findings and resolution status; agreements to sign; pre-funding conditions; revision / withdrawal request (reason required; goes to super admin approval).

### Transfers (13)
- Per tranche: scheduled amount and date, Mark as sent (UTR, amount, date, proof upload), "Startup confirmed receipt", "Verified by Finance", remaining to deploy.

### Announcements (14)
- Proposed wording with the three figures labelled Announced / Committed / Verified deployed. Approve (publishing is then allowed) or Request change.

## UX improvements over the raw SOP
1. Season meter always visible and always live, so the investor never over-commits.
2. Match cards explain *why* a startup was matched using only investor-visible factors.
3. All "indicative" amounts are visibly labelled so they cannot be mistaken for commitments.
4. Every team-proposed slot is a one-tap approve; conflicts with the investor's other approved slots are flagged.
5. Investors who are slow get a gentle reminder sequence before the system records "No response".
