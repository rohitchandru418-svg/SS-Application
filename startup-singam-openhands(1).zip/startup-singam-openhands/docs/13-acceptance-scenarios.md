# 13 – Cross-persona acceptance scenarios

Implement each scenario as a Playwright test with multiple browser contexts (one per persona) open at once, so that live propagation is tested. IDs are referenced from the phase files. "Live" = visible within 2 s without reload.

| ID | Scenario | Personas | Must prove |
|---|---|---|---|
| S01 | Founder registers, drafts at 60%, sees missing items, resumes on mobile viewport, submits at 100% | Founder, RM | RM auto-assigned; acknowledgement sent (email + WhatsApp stub + in-app); RM queue shows it live; application locked for founder |
| S02 | Idea-stage startup reaches 100% without financials | Founder | Completeness rule |
| S03 | Repeat applicant from last season | Founder, RM | Duplicate check links prior application; profile pre-filled |
| S04 | RM records Information required with 2 items; founder answers one; on day 8 auto-Hold | Founder, RM | Founder sees exact items only; label "On hold" after expiry; score never in founder API response |
| S05 | Proceed → bootcamp → preparation complete → analyst | RM, Founder, Analyst | Analyst API responses and file downloads contain no founder name/email/phone; founder sees "In progress" |
| S06 | Analyst Conditional proceed | Analyst, RM | Founder sees "Fit check done"; SR task created; IRR handover blocked until task done |
| S07 | Analyst Reject | Analyst, RM | RM has no action to override; founder sees mapped label |
| S08 | MoU shared on a Friday before a holiday | RM, Founder, Legal | Day 4 / day 7 computed with working-day calendar; Legal Q&A logged |
| S09 | Founder negotiates; super admin approves; Legal v2; RM shares | Founder, RM, Super admin, Legal | Clock restarts; founder sees v2 live |
| S10 | MoU signed → IRR; Finance posts 3 queries; founder uploads; lead reviews; super admin approves; IR accepts | Founder, Finance, Fin. lead, Super admin, IRM | Queries word for word; versions kept; IR accept gate |
| S11 | Investor journey to ACTIVE | Investor, IRM, Super admin, Legal | Grade never in investor API; eligibility policy version stored; season meter appears |
| S12 | Matching: suggestions, circulation, investor views IRR (no download, watermark, view logged), accepts | IRM, Investor, Founder | Founder sees investor name after acceptance; match % breakdown limited to external factors |
| S13 | Virtual pitch: IRM proposes slots, investor approves, founder books, pitch, investor submits Ready to invest (indicative) | IRM, Investor, Founder | Indicative labelled; meter Committed unchanged |
| S14 | IRM records verdict on behalf from a call | IRM, Investor | Investor sees "Recorded by your IR manager" |
| S15 | Verdict due date passes | System | NO_RESPONSE recorded; both portals show it |
| S16 | Pitch Day with Golden Pass; committee Proceed | IRM, Founder, Investor | Fee request with 15-day clock, Production advance notice, SR informed – all automatic |
| S17 | Committee Not selected | IRM, Founder | Founder sees only "Better luck next time – try again next season."; internal reason absent from founder API |
| S18 | Upfront fee: turnover, fee schedule v1, invoice (Zoho stub), founder uploads screenshot | Finance, Founder | Status "Proof uploaded – verifying"; not Paid until bank-matched receipt |
| S19 | Extension 5 days (Finance lead) and 10 days (super admin) | Founder, Fin. lead, Super admin | Original due date kept; ageing from original |
| S20 | Full payment verified | Finance, IRM, Production | Handover pack auto-assembled, IR approves, Production accepts, AV bookable; pack excludes confidential deal data |
| S21 | Episode allocated; IRR not yet viewed by a panel investor 15 days before shoot | System, IRM | 2-week rule alert at T−14 |
| S22 | Mock readiness approved by super admin; main shoot with 2 investors (lead + co), one withdraws on set | Production, IRM, Founder, Investors, Super admin | Exception logged; replacement search opened; 1 deal created; founder sees lead/co |
| S23 | Deal room: thread recorded at 50 h | IRM | Compliance breach flagged |
| S24 | DD with HIGH finding; cannot move to agreements until resolved | Legal, IRM, Founder | Gate enforced; founder sees DD request only, not finding text (A-65) |
| S25 | Commitment revision requested by investor | Investor, IRM, Super admin | Approval required; meter and founder card update after approval |
| S26 | Tranche: investor marks sent with UTR, founder confirms, Finance verifies | Investor, Founder, Finance | Both portals and meter update live; success-fee task created |
| S27 | Partial reversal after success fee invoiced | Finance | Deployed and fee base reduced; credit note task |
| S28 | Success fee paid net with TDS; Form 16A later | Founder, Finance | Paid (TDS pending) → reminders → closed after certificate; account balances |
| S29 | Episode edit approved; air date; promo assets approved by CEO; founder posts link | Production, Super admin, Marketing, Founder | Founder sees only approved assets; posting % updates |
| S30 | Announcement: investor approves wording; claim flag when announced ≠ deployed | Marketing, Investor | Cannot publish without investor approval |
| S31 | Founder feedback routed to Production | Founder, Marketing, Prod. head | Feedback actions logged |
| S32 | Community: person who is founder + mentor; referral creates investor lead linked to existing person | Community, IRM | No duplicate person; membership grants no deal access |
| S33 | Reassignment of a startup from RM A to RM B | Super admin, RMs | Scope switches immediately; audit entry; founder sees new RM |
| S34 | Approval left 3 working days | Super admin | Shown overdue on dashboard |
| S35 | Permission fuzz: for each external persona, call every API endpoint with another party's ids | Founder, Investor | 403/404 everywhere |
