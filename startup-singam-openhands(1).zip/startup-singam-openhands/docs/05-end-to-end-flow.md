# 05 – End-to-end flow, hand-offs and the sync matrix

## 5.1 The lifecycle in one sequence

Season set up (Super admin: window, fee schedule version, episodes, committee, templates)
│
├── INVESTOR TRACK (can start any time in the season) ───────────────────────────┐
│   Express interest → IRM assigned → profile → participation agreement + NDA    │
│   → verification (eligibility policy) → grading (super admin approves)         │
│   → season allocation proposed → investor confirms → "active"                  │
│                                                                                │
└── STARTUP TRACK                                                                │
    Founder registers → profile → application draft → submit (100%)              │
    → RM auto-assigned, acknowledgement, duplicate check                         │
    → screening (100 marks) → Proceed │ Info required (7 d → auto-Hold) │ Hold │ Reject
    → bootcamp batch → preparation complete                                      │
    → analyst pool (redacted) → Proceed │ Conditional │ Hold │ Reject (5 wd)     │
    → MoU (wd 4 Legal Q&A, wd 7 deadline) → Signed │ Negotiate (v2, clock restart) │ Discontinue
    → IRR request → Finance queries to founder → report → lead review → super admin approval
      (+ conditional-proceed condition cleared) → handover to IR → IR accepts     │
                                                                                 ▼
    MATCHING (needs: accepted IRR + active investors with unused allocation)
    → system suggests → IRM approves circulation → pairing per investor
    → investor reviews IRR → accept/decline → virtual pitch (5+5) → verdict per pairing
    → Pitch Day (Next stage / Ready) → 1:1 slots → Golden Pass / written commitment
    → committee pack → Proceed │ On hold │ Rejected
       └─ on Proceed, automatically: upfront fee request (15 d) + Production advance notice + SR informed
    → turnover verified → fee calculated & approved → invoice (Zoho) → proof → verified (bank)
       └─ on full payment verified, automatically: handover pack → IR approves → Production accepts
    → AV shoot → episode allocation + IR builds panel → pre-shoot confirmation (2-week IRR rule)
    → pre-shoot docs per signing event → mock shoot → super admin readiness approval
    → MAIN SHOOT: offers, accepted terms, lead/co, ICL + SDAL (paper, uploaded) → Deal confirmed
       ├── TELECAST TRACK: post-shoot signatures → edit → super admin approval → air date
       │    → founder notified → promo assets (CEO approves) → founder posts → telecast
       │    → post-telecast activity → founder feedback → Production
       └── DEAL TRACK (one per accepted investor):
            thread within 48 h → term sheet → DD (Legal tasks, findings) → definitive agreements
            → pre-funding conditions → tranche scheduled → investor marks sent → founder confirms
            → Finance verifies with bank evidence → (reversal if returned)
            → success fee calculated → lead review → invoice per tranche → founder pays net + TDS
            → Form 16A → reconciliation closed
            → public announcement (investor approves wording) → published
    → Community: alumni, events, support requests, referrals into next season

## 5.2 Hand-off register (every cross-team transition)

| # | From → To | Trigger event | What is handed over | Acceptance step? | Automatic? |
|---|---|---|---|---|---|
| H1 | Founder → SR | `application.submitted` | Application snapshot | No (auto-assign RM) | Yes |
| H2 | SR → Analyst | `analyst.referral.created` | Redacted application + bootcamp outputs | Pool assignment | Assignment auto (A-33) |
| H3 | Analyst → SR | `analyst.evaluation.submitted` | Recommendation + reason + concerns | SR review | Notification auto |
| H4 | SR ↔ Legal | `mou.shared`, `mou.negotiation.requested` | MoU version, founder questions / requested changes | Legal Q&A logged | Notification auto |
| H5 | SR ↔ Super admin | `mou.negotiation.requested` | Negotiation request | Approval item | Yes |
| H6 | SR → Finance | `irr.requested` (on `mou.signed`) | Startup, MoU, application | Finance accepts | Alert auto |
| H7 | Finance → Super admin | `irr.submitted_for_approval` | IRR version | Approval item | Yes |
| H8 | Finance → IR | `irr.approved` | Approved IRR version | IR accepts | Notification auto |
| H9 | IR → Investor | `pairing.circulated` | IRR view access, match % | Investor accepts/declines | — |
| H10 | IR → Committee/Mgmt | `committee.pack.compiled` | Pack | IR records decision | — |
| H11 | IR → Finance, Production, SR | `committee.decision.proceed` | Fee request, advance notice | — | **Yes, no manual step** |
| H12 | Finance → Production | `fee.upfront.fully_verified` | Auto-assembled handover pack | IR approves, Production accepts | Assembly auto |
| H13 | Production ↔ IR | `av.completed` | Episode allocation, panel build | Production head approves | — |
| H14 | Production → Super admin | `mock.readiness.submitted` | Readiness | Approval item | Yes |
| H15 | Production → IR | `mainshoot.deal.confirmed` | Accepted deal terms per investor | IR opens deal room | Deal records auto-created |
| H16 | IR ↔ Legal | `deal.opened` | DD task list | Legal runs DD | DD tasks auto-created from template (A-34) |
| H17 | Investor/Founder → Finance | `tranche.reported_sent`, `tranche.receipt_confirmed` | UTR, proof, bank statement | Finance verifies | — |
| H18 | Finance (internal) | `tranche.verified` | Success-fee task | — | Yes |
| H19 | Production → Marketing | `episode.approved` | Approved episode | Marketing schedules | Notification auto |
| H20 | Marketing → Investor | `announcement.drafted` | Wording + three figures | Investor approves | — |
| H21 | Marketing/Founder → Production | `feedback.submitted` | Founder feedback | Production head reviews | Routing auto |
| H22 | Community → SR / IR | `referral.created` | Lead linked to existing or new record | SR/IR qualifies | Duplicate link auto |

## 5.3 Sync matrix – internal action → what external users see (live)

All changes below are written once to the shared database. The external portal reads them through its projection and receives a realtime invalidation. "Live" means the open screen updates within 2 seconds without reload, plus the listed notification.

| Internal action (who) | Founder sees | Investor sees | Notification |
|---|---|---|---|
| RM auto-assigned (system) | RM name on application and Next step card | — | Founder: acknowledgement (email, WhatsApp, in-app) |
| Screening verdict recorded (RM) | Verdict label; for Info required, the exact items + reply-by date | — | Founder |
| Bootcamp invite / session / action item (RM) | Invite card, sessions, checklist items | — | Founder |
| Preparation complete (RM) | Stage moves to "Investment fit check – In progress" | — | Founder (in-app) |
| Analyst submits (Analyst) | "Fit check done" (or On hold / Not selected – A-15); no score | — | Founder |
| MoU shared / v2 shared (RM) | MoU download, Q&A date, day-7 countdown (restarted for v2) | — | Founder |
| Legal Q&A logged (Legal) | Q&A held, answers summary (A-35) | — | Founder |
| IRR query posted (Finance) | New checklist item word for word with due date | — | Founder; RM in-app |
| IRR approved & accepted (Finance → IR) | Stage moves to "Investor matching and virtual pitch" (once first pairing is circulated – A-36) | — | — |
| Pairing circulated (IRM) | Investor name appears on matching list (after investor accepts – A-37) | Match card with match %, IRR view, respond-by date | Investor |
| Slots proposed / approved (IRM / investor) | Approved slots available to book | Slots to approve | Both |
| Verdict recorded on investor's behalf (IRM) | Verdict on that investor's card | Verdict appears in their portal as recorded by IRM | Both |
| Golden Pass / written commitment recorded (IRM) | Outcome on investor card | Shown as recorded | Both |
| Committee decision (IRM) | Final selection label | Committee result for that startup | Both |
| Fee invoiced (Finance) | Amount, FY, turnover basis, invoice, bank details, due date | — | Founder |
| Extension approved (Finance lead / super admin) | "Extension approved", new due date | — | Founder |
| Receipt verified (Finance) | "Paid" / "Part paid" | — | Founder |
| AV / mock scheduled, checklist items (Production) | Date, location, prep list, checklist | — | Founder |
| Panel confirmed / pre-shoot items (IRM / Production) | — | Episode, shoot date, briefing, documents needed | Investor |
| On-set capture (Production) | Offers accepted, lead/co, conditions, docs signed/outstanding | Offers, accepted deal, split, conditions, ICL status | Both |
| Deal room milestone / DD request / finding (IRM / Legal) | Deal card for that investor; DD request with upload | Deal room for that startup | Both |
| Withdrawal approved + replacement (IRM / super admin) | Withdrawal reason (A-38) and replacement status | Withdrawal recorded | Both |
| Tranche verified (Finance) | Received updates, pending decreases | Verified; season meter Deployed increases | Both |
| Success fee invoiced (Finance) | Invoice amount, due date | — | Founder |
| Air date / approved assets (Marketing) | Episode, air date, approved posts | — | Founder |
| Announcement drafted (Marketing) | Approved wording only after investor approves (A-39) | Proposed wording to approve | Investor |
| Event published (Community) | Events list | Events list | Members per preferences |

## 5.4 Sync matrix – external action → what internal users see (live)

| External action | Internal record change | Who sees it, where |
|---|---|---|
| Founder submits application | Application `SUBMITTED`, RM assigned | RM action queue; SR team view intake counts |
| Founder replies to info-required items | Items `ANSWERED`; screening back to RM | RM queue (top, due-sorted) |
| Founder accepts bootcamp invite / completes action item | Attendance / item status | RM queue, bootcamp metrics |
| Founder signs / negotiates / discontinues MoU | MoU response recorded | RM; Legal (negotiate); super admin approvals (negotiate) |
| Founder uploads IRR document | Query `SUBMITTED` | Finance queue; RM follow-up view |
| Founder books slot | Slot booked | IRM, investor |
| Founder uploads payment proof | Fee `PROOF_UPLOADED` | Finance "Receipts to check"; RM follow-up |
| Founder requests extension | Approval item created | Finance lead (≤ 7 d) or super admin (> 7 d) |
| Founder confirms availability / checklist | Production records updated | Coordinator "My shoots" |
| Founder uploads SDAL / DD docs | Signature / DD task updated | Production, IRM, Legal |
| Founder confirms tranche receipt | Tranche `FOUNDER_CONFIRMED` | Finance verification queue; IRM |
| Founder pays success fee + TDS | Receipt pending verification | Finance |
| Founder posts content / gives feedback | Posting `POSTED`; feedback routed | Marketing, SR, Production |
| Founder raises support request | Support request `OPEN` | Community |
| Investor registers / completes profile | Investor lead → IRM assigned | IRM queue |
| Investor uploads agreements / answers verification | Statuses updated | IRM, Legal |
| Investor confirms season commitment | Allocation `CONFIRMED` | IRM; IR capital metrics |
| Investor accepts/declines match, asks question, requests doc, gives indicative amount | Pairing updated | IRM queue; questions routed to SR/Finance for founder answer (A-40) |
| Investor approves slot / submits verdict / acknowledges minutes | Pairing updated | IRM; founder card |
| Investor confirms commitment in writing | Panel record | IRM, Production |
| Investor requests revision / withdrawal | Approval item (super admin) | IRM, super admin |
| Investor marks tranche sent | Tranche `INVESTOR_REPORTED` | Finance, IRM, founder (to confirm) |
| Investor approves announcement | Announcement `APPROVED` | Marketing |
| Investor refers another investor | Referral record | Community, IR |

## 5.5 Dependencies that gate progress (enforced by the system)

| Gate | Requires |
|---|---|
| Screening can start | Application `SUBMITTED` |
| Send to analyst | Bootcamp preparation `COMPLETE` |
| MoU can be shared | Analyst `PROCEED` or `CONDITIONAL_PROCEED` |
| IRR request | MoU `SIGNED` |
| IRR handover to IR | IRR `APPROVED` by super admin **and** all conditional-proceed conditions cleared |
| Matching | IRR accepted by IR; investor `ACTIVE` (verified, graded+approved, allocation confirmed, agreements signed) |
| Virtual pitch | Investor accepted the match |
| Pitch Day pairing | Virtual pitch verdict `NEXT_STAGE` or `READY_TO_INVEST` |
| Committee | Pitch Day done for the startup |
| Upfront fee request | Committee `PROCEED` |
| AV booking | Upfront fee fully verified **and** handover pack IR-approved and Production-accepted |
| Episode allocation | AV completed |
| Mock shoot | Pre-shoot documents ready |
| Main shoot | Mock readiness approved by super admin |
| Deal room | Deal confirmed on set |
| Tranche transfer can proceed | Pre-funding conditions met (IR confirms) |
| Success fee | Tranche verified |
| Announcement publish | Investor approval |
| Reconciliation closed | Account balances and all TDS certificates in |
