# 08 – Permissions and visibility

Permissions are checked on the server in three layers. Implement them as one policy module in `packages/domain/permissions` with a single entry point `can(viewer, action, resource)` and a single projector `project(viewer, resource) → visible fields`. Every API response for an entity must go through `project`.

## Layer 1 – Actions by role

Legend: **O** owns (create/update/transition), **A** approves, **V** view, **F** view + notes + follow-up tasks, **–** no access.

| Area | Founder | Investor | RM | Analyst | Finance | Fin. lead | Legal | IRM | Prod. coord | Prod. head | Marketing | Community | Super admin |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Season, policies, templates | – | – | V | – | V (fee schedule) | V | O (templates) | V | – | – | – | – | O / A |
| Users & roles | – | – | – | – | – | – | – | – | – | – | – | – | O |
| Startup profile | O (own) | – | O | V (redacted) | V | V | V | V | V (permitted) | V | V (publication info) | V (member data) | V |
| Application, screening | O (own draft) / V | – | O | – | – | – | – | V | – | – | – | – | V, reassign |
| Bootcamp | V + respond | – | O | – | – | – | – | – | – | – | – | – | V |
| Analyst evaluation | – | – | V | O | – | – | – | V (A-52) | – | – | – | – | V |
| MoU | V + respond | – | O | – | – | – | O (Q&A, v2) | – | – | – | – | – | A (negotiation) |
| IRR | V (own queries only) | V (shared version, view-only) | F | – | O | A (review) | – | V, accept | – | – | – | – | A (final) |
| Investor record, verification | – | O (own profile) / V | – | – | – | – | V (agreements) | O | – | – | – | V (member data) | V |
| Grade | – | – | – | – | – | – | – | O | – | – | – | – | A |
| Season allocation | V + confirm | V + confirm (own) | – | – | – | – | – | O | – | – | – | – | V |
| Pairings, pitches, verdicts | V (own cards) + book | O (own) | F | – | – | – | – | O | – | – | – | – | V |
| Committee | V (result) | V (result for their pairings) | F | – | – | – | – | O (pack, record) | – | – | – | – | V |
| Upfront fee | V + respond | – | F | – | O | A (standard, ext ≤ 7 d) | – | V | – | – | – | – | A (exceptions, ext > 7 d) |
| Production (shoots) | V + respond | V (panel, briefing) | F | – | – | – | – | O (panel) / F | O | A (episode alloc.) | – | – | A (mock, edit) |
| Handover pack | – | – | V | – | V | V | – | A | O (accept) | O | – | – | V |
| Deals, DD, agreements | V (own) + respond | V (own) + respond | F | – | O (DD finance tasks) | V | O (DD, agreements, conditions) | O | – (A-53) | – | – | – | A (revisions/withdrawals) |
| Tranches | V + confirm | V + report | F | – | O (verify) | V | – | F | – | – | – | – | V |
| Success fee, reconciliation | V + pay | – | F | – | O | A | – | V | – | – | – | – | A (waivers etc.) |
| Telecast, promo, posting | V + post | – | F | – | – | – | – | – | V | V | O | – | A (promo assets) |
| Announcements | V (approved) | A (own) | V | – | – | – | – | F | – | – | O | – | V |
| Community | V + register + request | V + register + refer | V | – | – | – | – | V | – | – | V | O | A (budget) |
| Approvals inbox | – | – | – | – | – | own items | – | – | – | own items | – | – | O |
| Audit log | – | – | own records | – | own records | own records | own records | own records | – | – | – | – | V all |

## Layer 2 – Record scope

| Role | Records in scope |
|---|---|
| Founder | Only their startup and its applications, and only stages reached (future stages show as upcoming without data) |
| Investor | Only their investor record, their pairings, deals and tranches, and startups circulated to them |
| RM | Startups assigned to them (write); all SR startups read-only in Team view (A-54) |
| Analyst | Referrals assigned to them only |
| IRM | Investors assigned to them, pairings and deals where they are the accountable IRM (write); others read-only via Startup 360 |
| Finance, Legal, Marketing, Community | All records in their queue (department-wide) |
| Production coordinator | Startups assigned to them (write); Production head sees all |
| Super admin | Everything |

Reassignment changes scope immediately and is audited.

## Layer 3 – Field visibility classes

| Class | Fields (examples) | Visible to |
|---|---|---|
| `SCORE_SCREENING` | 100-mark scorecard, criterion comments, evidence | RM (own), SR team view, super admin |
| `SCORE_ANALYST` | analyst scores, willingness to invest, indicative amount, concerns | Analyst (own), RM, IRM (A-52), super admin |
| `GRADE` | grade level, dimensions, evidence, review date | IRM, super admin |
| `FOUNDER_PII` | founder/co-founder names, emails, phones, personal IDs; founder name inside documents | Everyone internal **except Analyst**; founder (own); investor sees founder names only (A-07) |
| `CONFIDENTIAL_DEAL` | investor confidential remarks, deal documents, DD findings, term sheets, agreements, verdict comments | IR, Legal, Finance, super admin; founder/investor only their own deal documents |
| `PERMITTED_BUSINESS` | company name, sector, stage, product summary, pitch materials, selection decision, payment clearance | Production, Analyst (minus PII), Marketing (publication subset) |
| `PUBLICATION` | approved wording, approved assets, air date | Marketing; founder after approval |
| `FINANCE_INTERNAL` | fee calculation workings, exceptions, ledger | Finance, super admin; founder sees upfront fee amount + FY + turnover basis; for success fee **invoice amount only** |
| `INTERNAL_NOTE` | notes, internal reasons (e.g. committee reason) | Internal roles with record access |
| `MATCH_INTERNAL` | grade and thesis weighting, unused allocation in match score | IRM, super admin |
| `MATCH_EXTERNAL` | match % and breakdown on sector, stage, ticket, geography | Investor (own pairings), IRM |

## Analyst redaction (system-enforced)

- API: `project()` strips `FOUNDER_PII` for Analyst viewers.
- Text fields: run a redaction pass replacing any founder/co-founder name, email or phone occurring in free text (application answers, SR notes shared to analyst) with `[Founder]`, `[Co-founder 1]`, `[contact hidden]`.
- Files: analyst downloads/views of founder-uploaded documents are served from a **redacted variant** (`File.redactedVariantOf`). PDFs: text-layer redaction of known PII strings plus a manual "needs review" flag if redaction confidence is low (A-55); until reviewed, the file is not available to the analyst.
- Exports (CSV/PDF) generated for analysts go through the same projector.
- Tests: for every endpoint reachable by an Analyst, assert no founder name/email/phone string appears in the JSON or file bytes.

## External projections

Implement one projector per external persona per entity in `packages/domain/projections/{founder,investor}`:
- Map internal status → external label (tables in `02` and `03`).
- Return only whitelisted fields (deny by default).
- Collapse internal sub-states: e.g. IRR `IN_PREPARATION/IN_REVIEW/AWAITING_APPROVAL` → founder sees only their open queries and "The team is preparing your report".
- Never return: scores, grades, internal notes, internal reasons, other parties' data, analyst outputs, match internals.
- Unit test each projector with a fully populated internal record and assert the exact output shape (snapshot), so any new field added later is hidden unless explicitly whitelisted.

## Acting on behalf

IRMs may record investor responses (verdicts, acknowledgements, tranche sent) on the investor's behalf; RMs may record founder MoU responses. The record stores `recordedById`, `onBehalfOfId`, `sourceNote` (e.g. "phone call 12 Nov"). External portals show "Recorded by your Investor Relations manager on <date>".

## Approvals routing

| Approval type | Raised by | Approver role |
|---|---|---|
| `INVESTOR_GRADE` | IRM | Super admin |
| `COMMITMENT_REVISION` / `COMMITMENT_WITHDRAWAL` | IRM (or investor request) | Super admin |
| `MOU_NEGOTIATION` | RM / founder request | Super admin |
| `IRR_FINAL` | Finance (after lead review) | Super admin |
| `FEE_STANDARD` | Finance | Finance lead |
| `FEE_EXCEPTION` / `FEE_DISCOUNT` | Finance | Super admin |
| `EXTENSION` ≤ 7 days | Finance / founder request | Finance lead |
| `EXTENSION` > 7 days, `WAIVER`, `REFUND`, `DISPUTE` | Finance | Super admin |
| `MOCK_READINESS` | Production | Super admin |
| `EPISODE_EDIT` | Production head | Super admin (proposed – A-30) |
| `EPISODE_ALLOCATION` | Production + IR | Production head |
| `HANDOVER_PACK` | SYSTEM | IRM |
| `TEMPLATE_VERSION` | Legal | Super admin |
| `PROMO_ASSET` | Marketing | Super admin (CEO) |
| `EVENT_BUDGET` | Community | Super admin |
| `ANNOUNCEMENT` | Marketing | Investor (external approval) |

All internal approvals: due in 2 working days; any super admin can decide; the decider is recorded.
