# 02 – Founder journey (external)

Founder-facing stage names hide the internal SOP stages. Steps 0–14 are sequential. After the main shoot two tracks run **in parallel**: Telecast (15) and Deals → Funds → Success fee (16–18), and the deal track is **one card per investor**. Community (19) opens from committee Proceed (A-12), so the founder can join events and raise support requests while the later stages run; full "alumni" status follows when every track is complete.

Columns: **Founder sees** = the stage label on the founder's timeline. **Internal stage** = what staff work on. **Shown** = the only information the founder gets. **Action** = what the founder can do. **Deadline** = what countdown the founder sees. **Team** = which department is behind it (the founder sees the named RM as their contact throughout; A-13).

| # | Founder sees | Internal stage | Shown to founder | Founder action | Deadline shown | Team |
|---|---|---|---|---|---|---|
| 0 | Profile | Startup record | Company, founders, sector, stage, financials, documents. Reused every season. | Register (one founder per startup); complete profile; update between seasons | — | SR |
| 1 | Application – draft | Application | % complete and what is missing (e.g. "Pitch deck not uploaded"). Idea stage skips financials. Draft expires when the season closes; profile stays live. | Fill in, save, resume | "Applications close in X days" | SR |
| 2 | Application – submitted | Formal submission | 100% complete, acknowledgement, RM assigned (name shown). Application locked. | — | — | SR |
| 3 | Internal review | Internal screening (100 marks) | Verdict only, no score: Proceed / Information required (exact items) / On hold / Not selected | Reply only to the specific items requested (form stays locked) | Reply-by date | SR |
| 4 | Pre-bootcamp | Prep bootcamp | Invitation, briefing done, sessions, action items, preparation complete | Accept invite, attend, complete action items | Session dates | SR |
| 5 | Investment fit check | Analyst screening | "In progress", then "Fit check done". No scores, willingness or indicative amount. | — | — | SR |
| 6 | MoU | Startup MoU | MoU shared (download), Legal Q&A on working day 4, signing deadline working day 7 | Sign and upload / Want to negotiate (reason) / Not proceeding (reason) | Day-7 countdown | SR, Legal |
| 7 | Document scrutiny | IRR | Checklist with team queries shown word for word (e.g. "Upload MCA document", "Turnover certificate") | Upload requested documents | Per-query due date | SR, Finance/IRR |
| 8 | Investor matching and virtual pitch | Matching + virtual pitch | Matched investors by name, slots, then verdict per investor: Ready to invest / Next stage / Information requested / On hold / Pass / No response | Pick slots, attend, answer information requests | Slot dates | IR |
| 9 | Pitch Day | Pitch Day + Golden Pass | 1:1 slots, then outcome per investor: Golden Pass / Written commitment / No response / Pass | Pick slots, attend | Pitch Day date | IR |
| 10 | Final selection | Final Shortlisting Committee | Proceed / On hold / Not selected. Not selected shows no reason, only "Better luck next time – try again next season." | — | — | Management |
| 11 | Upfront fee | Upfront fee workflow | Fee amount, turnover and FY it is based on, invoice, bank details. 15-day clock from committee Proceed. Status: Proof uploaded – verifying / Paid / Part paid / Overdue / Extension approved | Upload payment proof; request extension with reason | 15 days from committee decision | Finance |
| 12 | AV shoot | AV shoot | Date, location, what to prepare | Confirm availability | Shoot date | Production |
| 13 | Mock shoot | Mock shoot | Readiness checklist (pitch, demo, props) | Complete checklist items | Shoot date | Production |
| 14 | Main shoot | Main shoot | Offers accepted, lead and co-investors, conditions, documents signed and outstanding | Sign Startup Deal Acceptance Letter on paper on set, then upload | Same day or 24 h (A-14) | Production, IR |
| 15 ∥ | Telecast and promotion | Marketing | Episode and air date, approved posts to share, approved announcement wording | Post content, submit link, mark done, give feedback | Air date | Marketing |
| 16 ∥ | Deal closure (card per investor) | Post-shoot closure | Term sheet, DD requests, agreements, conditions, expected date per milestone, withdrawal reason or replacement investor | Upload DD documents, sign agreements | Milestone dates | IR, Legal |
| 17 ∥ | Funds received | Deployment tracking | Per investor: committed / received / pending, tranche by tranche. Verified only with investor report + founder confirmation + bank evidence. | Confirm receipt, upload bank statement | Scheduled tranche dates | IR, Finance |
| 18 ∥ | Success fee | Post-funding collections | Success-fee invoice amount only (one invoice per verified tranche), status, due date | Upload payment proof, enter TDS deducted; upload Form 16A when issued | Invoice due date | Finance |
| 19 | Community | Community | Alumni, mentors, events, support requests | Join events, request support | — | Community |

## External label mapping (internal value → what the founder sees)

| Internal | Founder label |
|---|---|
| Screening `PROCEED` | "Proceed" |
| Screening `INFO_REQUIRED` | "Information required" + exact items list |
| Screening `HOLD` / `AUTO_HOLD` | "On hold" |
| Screening `REJECT` | "Not selected" |
| Analyst any state before submit | "In progress" |
| Analyst `PROCEED` / `CONDITIONAL_PROCEED` | "Fit check done" |
| Analyst `HOLD` | "On hold" (A-15) |
| Analyst `REJECT` | "Not selected" (A-15) |
| Committee `PROCEED` / `ON_HOLD` / `REJECTED` | "Proceed" / "On hold" / "Not selected – Better luck next time – try again next season." |
| Pairing verdicts | shown as-is (see list in row 8) |
| Fee statuses | as listed in row 11 |

## Founder screen behaviour (what OpenHands must build)

### Home ("Your journey")
- A **Next step card** at the top: one sentence of what is needed, the deadline countdown, a primary button that goes straight to the action, and the RM's name. If nothing is needed: "Nothing needed from you right now – <team> is <doing X>" (e.g. "The team is preparing your Investment Readiness Report").
- A **timeline** of stages 0–19 with founder labels only. Completed, current, upcoming. After stage 14 the timeline splits into two lanes (Telecast, Deals) and the Deals lane shows one row per investor.
- **Status chips** always include text. Countdown chips switch to "Overdue" when past due.
- **Updates feed**: every change that touches the founder (verdict recorded, query posted, slot proposed, invoice issued, tranche verified) appears live (see `09` realtime) and links to the place to act.

### Profile (stage 0)
- Sections: Company, Founders (the logged-in founder + co-founders as records), Sector & stage, Financials (hidden when stage = Idea), Documents.
- Reused every season: a new season's application pre-fills from the profile; editing the profile between seasons is allowed, while an application is submitted the profile fields included in it are **snapshotted** into the application (A-16) so later profile edits do not change a locked application.

### Application (stages 1–2)
- Section-by-section form with autosave; a completeness meter showing % and an explicit list of missing items, each linking to its field.
- Idea-stage startups skip financials (both in the form and in completeness).
- "Applications close in X days" from the season's window. When the season closes, unsubmitted drafts move to `EXPIRED` (read-only, profile untouched).
- Submit only at 100%. After submit: acknowledgement screen and email/WhatsApp, RM name and photo slot, application read-only.

### Information required (stage 3)
- The founder sees only the requested items, each with its own reply box / upload, and the reply-by date. The rest of the form stays locked. Submitting replies notifies the RM.

### Bootcamp (stage 4)
- Invitation card with Accept. Session list with dates. Action items checklist (each item: title, due, done/not done, upload if needed). "Preparation complete" appears only when SR marks it.

### MoU (stage 6)
- Download MoU (current version), Legal Q&A date (working day 4), signing deadline (working day 7) countdown.
- Three choices: **Sign and upload** (upload signed copy), **Want to negotiate** (reason required), **Not proceeding** (reason required, confirmation step). On negotiate, the screen shows "Your request is with the team"; when v2 is shared, the clock restarts and the screen shows v2.

### Document scrutiny (stage 7)
- Checklist of queries posted by the IRR team, text shown word for word, each with due date, upload/reply, status (Open / Submitted / Accepted / Re-requested).

### Matching, virtual pitch, Pitch Day (stages 8–9)
- One card per matched investor: investor name, slot options (only team-proposed slots that the investor has approved – A-17), chosen slot, joining details, verdict once recorded, and any information requests from that investor (reply/upload inline).

### Final selection (stage 10)
- Shows result only. "Not selected" shows exactly: "Better luck next time – try again next season." and a button to keep the profile updated for next season.

### Upfront fee (stage 11)
- Fee amount, financial year and turnover used, invoice (download), bank details, 15-day countdown, status. Upload payment proof (status → "Proof uploaded – verifying"). Request extension (reason). Part paid shows paid vs remaining.

### Shoots (12–14)
- AV: date, location, prep list, "Confirm availability" (or propose a problem – A-18). Mock: readiness checklist. Main shoot: summary of accepted offers, lead / co-investors, conditions, list of documents signed vs outstanding, upload of the signed Startup Deal Acceptance Letter.

### Telecast & promotion (15)
- Episode and air date, approved posts (download/copy), approved announcement wording, posting brief. For each post: paste post link → "Posted". Feedback form after telecast (rating + comments – A-19).

### Deals, funds, success fee (16–18)
- One **deal card per investor**: milestones (term sheet, DD, agreements, pre-funding conditions, tranches) with expected dates; DD document requests with upload; agreements to sign; if the investor withdrew: reason and replacement-investor status.
- Funds: per investor committed / received / pending; per tranche scheduled date and amount; "Confirm receipt" with bank statement upload.
- Success fee: per invoice amount, status, due date; upload proof, enter TDS deducted; later upload Form 16A; reminders until uploaded.

### Community (19)
- Events (register), alumni directory and mentors (as permitted – A-20), support requests (type: investor intro, mentoring, customer connection, hiring, follow-on funding; with status and owner name).

## UX improvements over the raw SOP (apply throughout)
1. One Next step card instead of making the founder hunt through stages.
2. Every notification deep-links to the exact action screen.
3. Requests from any team (SR, IRR, Legal DD, Production checklists) use the same "request item" component: text word for word, due date, upload/reply, status – so the founder learns one pattern.
4. Nothing ever shows a score, grade, or internal reason; negative outcomes use the fixed kind wording, always with a next step (e.g. update profile for next season).
5. Parallel tracks after the shoot are shown side by side so the founder is never told "wait" on one track while the other needs them.
6. Save-and-resume everywhere; uploads resumable on mobile networks; camera upload on mobile.
