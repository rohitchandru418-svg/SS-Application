# 10 – Automation, deadlines, escalations and notifications

## 10.1 Clocks and deadlines (all from the spreadsheet unless an A-ID is given)

| Clock | Starts | Length | Unit | On expiry |
|---|---|---|---|---|
| Application window | Season opens | Season setup | dates | Drafts → `EXPIRED` |
| Info required (screening) | Verdict recorded | 7 | calendar days (A-41) | Auto-Hold |
| Analyst evaluation | Analyst assigned | 5 | working days | Overdue + escalation |
| MoU Legal Q&A | MoU shared | by day 4 | working days | Legal queue overdue |
| MoU signing | MoU shared (restarts on v2) | day 7 | working days | "Past day 7", escalation (A-47) |
| IRR query | Query posted | per query | set by Finance | Overdue on founder card + Finance queue |
| IRR with investors | Episode shoot date | ≥ 2 weeks before | calendar | Alert to IRM + IR compliance metric |
| Pairing response | Circulated | respond-by date set by IRM (default 5 working days – A-26) | | `NO_RESPONSE` |
| Verdict | Pitch held | verdict due date set by IRM (default 3 working days – A-26) | | `NO_RESPONSE` |
| Upfront fee | Committee Proceed | 15 | calendar days | `OVERDUE`; ageing buckets 0–15, 15–30, 30+ from original due date |
| Main-shoot signatures | Main shoot | same day or 24 h (A-14) | hours | Signatures past deadline metric; escalation |
| Deal communication thread | Deal confirmed | 48 | hours | Compliance breach flag |
| Milestones / tranches | Set by IRM | per milestone | dates | At-risk / overdue |
| Success-fee invoice | Invoiced | due date | | `OVERDUE` |
| Form 16A | Success fee paid | reminders (A-60) | | reminders until uploaded |
| Approvals | Approval created | 2 | working days | Overdue on super admin dashboard |
| Grade review | Grade approved | review date | | "Grade reviews due" metric |
| Event / support request | Created | due date | | Overdue |

Working days come from the `WORKING_DAY_CALENDAR` policy (weekends + public holidays list, versioned). Implement `addWorkingDays(date, n, calendarVersion)` and `workingDaysBetween()` in `packages/domain/time` with exhaustive tests.

## 10.2 Scheduler

- Every deadline creates a row in a `Deadline` index (subject, kind, dueAt, ownerUserId). The worker runs a job every minute picking deadlines due in the next minute, and also enqueues delayed BullMQ jobs at creation for precision. Jobs re-check the state before acting (the record may have moved on).
- Reminder cadence (policy `REMINDER_CADENCE`, default): 3 days before, 1 day before, on the day, then every 2 days overdue (max 3) – for founder and investor actions. Internal owners get it in their action queue and a daily digest.

## 10.3 Escalations

| Cause | Escalated to | Record |
|---|---|---|
| Analyst evaluation overdue | SR team view + super admin (A-27) | `Escalation(ANALYST_OVERDUE)` |
| MoU negotiation | Super admin | approval + escalation |
| MoU past day 7 | Super admin | escalation |
| Upfront fee overdue / extension requested | Finance lead or super admin per rule | approval |
| Shoot-day exceptions | IR / SR / super admin per exception table | escalation |
| Signature refused | IR + super admin | escalation |
| Deal thread not opened in 48 h | IRM + super admin | compliance flag |
| Approval past 2 working days | Super admin dashboard | overdue flag |

## 10.4 Notification catalogue

Channels: in-app always; email and WhatsApp for external users per their preferences (default both on); internal users get in-app + email digest (A-61). Every notification carries a deep link to the action screen. Templates live in `packages/copy/notifications`. WhatsApp templates must be pre-approvable short texts with a link.

| Key | Recipient | When |
|---|---|---|
| `founder.application.acknowledged` | Founder | Submitted (includes RM name) |
| `founder.application.closing_soon` | Founder with draft | 7, 3, 1 days before close |
| `founder.screening.verdict` | Founder | Verdict recorded |
| `founder.screening.info_required` | Founder | Items posted (+ reminders) |
| `founder.bootcamp.invite` / `.session_reminder` / `.action_item` | Founder | |
| `founder.fitcheck.done` | Founder | Analyst submitted |
| `founder.mou.shared` / `.qa_scheduled` / `.deadline_reminder` / `.v2_shared` | Founder | |
| `founder.irr.query` | Founder | Query posted |
| `founder.matching.investor_added` / `.slots_available` / `.verdict` / `.info_request` | Founder | |
| `founder.pitchday.slots` / `.outcome` | Founder | |
| `founder.committee.result` | Founder | |
| `founder.fee.invoiced` / `.reminder` / `.overdue` / `.extension_decision` / `.paid` | Founder | |
| `founder.shoot.av` / `.mock_checklist` / `.main` / `.signature_outstanding` | Founder | |
| `founder.telecast.air_date` / `.assets_ready` / `.posting_reminder` / `.feedback_request` | Founder | |
| `founder.deal.update` / `.dd_request` / `.agreement_to_sign` / `.withdrawal` | Founder | |
| `founder.tranche.confirm_receipt` | Founder | Investor reported sent |
| `founder.successfee.invoiced` / `.reminder` / `.form16a_reminder` | Founder | |
| `investor.invite_to_register` | Investor lead | Interest form submitted |
| `investor.agreements.to_sign` / `.verification.query` / `.verified` | Investor | |
| `investor.allocation.to_confirm` | Investor | |
| `investor.match.new` / `.respond_reminder` | Investor | |
| `investor.pitch.slot_to_approve` / `.verdict_due` / `.minutes_to_ack` | Investor | |
| `investor.pitchday.slots` | Investor | |
| `investor.committee.result` | Investor | |
| `investor.preshoot.confirm` / `.briefing` / `.irr_received` | Investor | |
| `investor.deal.update` / `.dd_query` / `.agreement_to_sign` | Investor | |
| `investor.tranche.due` / `.verified` | Investor | |
| `investor.announcement.to_approve` | Investor | |
| `internal.queue.new_item` | Owner | Any new item in their queue |
| `internal.approval.requested` / `.overdue` | Approvers | |
| `internal.escalation` | Escalation target | |
| `internal.digest.daily` | All internal users | 08:30 IST |
| `community.event.*` | Members | per preferences and consent |
