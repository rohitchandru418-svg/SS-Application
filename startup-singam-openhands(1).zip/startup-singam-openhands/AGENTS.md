# Standing rules for OpenHands – Startup Singam

Copy this file to the repository root as `AGENTS.md` and to `.openhands/microagents/repo.md`. These rules apply to every task in this repository.

## 1. Source of truth

- The specification lives in `/spec`. Before writing code for any phase, read `/spec/README.md`, the phase file, and every document the phase lists under "Read first".
- Do not invent business rules. If the spec does not cover something, check `/spec/docs/99-assumptions-and-gaps.md`. If it is not there either, implement the most conservative option (least data shown, least automatic action), make it configurable, add a `// ASSUMPTION:` comment, and append a new entry to the "Added during build" section of `99-assumptions-and-gaps.md` in the same PR.
- Reference assumption IDs in code comments, e.g. `// A-12: info-required window counts calendar days`.

## 2. Stack (fixed unless the spec owner changes it — see A-01)

| Concern | Choice |
|---|---|
| Language | TypeScript everywhere, `strict: true` |
| Monorepo | pnpm workspaces + Turborepo |
| API | NestJS (REST + OpenAPI generated from DTOs), `apps/api` |
| Web | Next.js (App Router) + React, `apps/web`, three route groups: `(founder)`, `(investor)`, `(internal)` |
| Database | PostgreSQL 16, Prisma ORM, `packages/db` |
| Jobs and timers | BullMQ on Redis (`apps/worker`) |
| Realtime | Server-Sent Events from the API, fed by Postgres outbox → Redis pub/sub |
| Files | S3-compatible storage (MinIO in dev), presigned uploads, virus-scan hook |
| Email | SMTP adapter (Mailpit in dev) |
| WhatsApp | Provider-agnostic adapter interface with a dev stub that logs messages (A-02) |
| Accounting | Zoho Books adapter interface with a dev stub (A-03) |
| Client data | TanStack Query; cache keys = resource keys used by realtime invalidation |
| Validation | Zod schemas shared in `packages/contracts` (API DTOs and web forms use the same schemas) |
| Tests | Vitest (unit), Supertest (API integration against a real Postgres via Testcontainers), Playwright (e2e) |
| Local run | `docker compose up` brings Postgres, Redis, MinIO, Mailpit; `pnpm dev` runs api, worker, web |

## 3. Architecture rules (non-negotiable)

1. **One shared data source.** Founder portal, investor portal and internal console read and write the same tables through the same API. Never create a separate "external copy" of a record. External screens are **projections**: functions in `packages/domain/projections` that take the shared record plus the viewer and return only what that viewer may see, using external stage names and labels.
2. **All writes go through domain commands** in `packages/domain` (e.g. `submitApplication`, `recordScreeningVerdict`). A command: checks permission, validates the state transition against `/spec/docs/07-state-machines.md`, writes the change, writes an audit entry, and writes one or more domain events to the `outbox` table, **in one transaction**.
3. **Side effects only from events.** Notifications, automatic records (e.g. the upfront fee request on committee Proceed), realtime pushes and Zoho sync are handled by event consumers in `apps/worker`, never inline in the command.
4. **Permissions are enforced on the server** at three levels: route/action (role), record (scope: assigned owner, department, own startup/investor), and field (visibility class). The web app may hide things for UX, but the API must never return a field the viewer is not allowed to see. Redaction for analysts applies to API responses, exports, generated PDFs and file downloads.
5. **Every status change is a state machine transition.** Status columns are enums. Illegal transitions throw `IllegalTransitionError`. Transition tables live in code next to the entity and must match `07-state-machines.md`.
6. **Every deadline is data.** Store `dueAt`, the rule that produced it, the policy version, and the original due date when an extension changes it. Never compute deadlines only in the UI.
7. **Policies are versioned** with effective dates (screening pass mark, eligibility rules, fee schedule, working-day calendar, success-fee structure). Records store the policy version they were evaluated under.
8. **Audit everything.** Who, when, what changed (before/after), on whose behalf (e.g. IRM recording an investor verdict from a call), reason when required.
9. **Money** is stored as integer paise (`BigInt`) with an ISO currency code (INR default). Never use floats for money or percentages; percentages as basis points.
10. **Time** is stored in UTC; displayed in Asia/Kolkata by default (A-04). Working days come from the working-day calendar policy.

## 4. UX rules

- Do not define colours, fonts, spacing scales or a design system. Import UI primitives only from `packages/ui` (the design-system slot). In P00 that package contains unstyled, accessible placeholder components; the business will replace their implementation without changing their props.
- Founder portal is mobile-first (designed at 360 px wide first). Investor portal and internal console are responsive, desktop-first.
- English only. All user-facing strings go through `packages/copy` (one place to edit wording), keyed by screen.
- Every external screen shows: current stage, what is needed from the user (if anything), the deadline, and who on the team is helping. See `docs/11-ux-and-screens.md`.
- WCAG 2.2 AA behaviour: keyboard access, focus management, labels, error text, no colour-only status (status chips must include text).

## 5. Code conventions

- Folder layout:
  ```
  apps/api        NestJS modules per bounded context (startups, applications, screening, bootcamp, analyst, mou, irr, investors, matching, pitches, committee, fees, production, deals, deployment, marketing, community, admin, approvals, notifications, files, realtime)
  apps/worker     event consumers, schedulers, adapters
  apps/web        Next.js, route groups (founder) (investor) (internal)
  packages/db     Prisma schema, migrations, seed
  packages/domain commands, state machines, projections, permission policies
  packages/contracts Zod schemas + generated API client
  packages/ui     design-system slot (placeholder components)
  packages/copy   user-facing strings
  ```
- One Prisma migration per phase minimum; never edit a merged migration.
- Seed script (`pnpm db:seed`) must create one user per role and at least one startup and investor at every stage reached so far (extended each phase).
- No secrets in code. `.env.example` lists every variable.

## 6. Definition of done for every phase

- [ ] All items in the phase's "Scope" are implemented in API, worker and the relevant portals.
- [ ] State transitions and permission rules for the phase have unit tests (allowed and forbidden cases, including a forbidden field-visibility test per external persona).
- [ ] API integration tests cover every command in the phase.
- [ ] Playwright e2e covers the phase's acceptance scenarios, including at least one test where an internal action appears live in an external portal (and the reverse) without reload.
- [ ] Seed data updated.
- [ ] `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm e2e` pass.
- [ ] New assumptions recorded in `/spec/docs/99-assumptions-and-gaps.md`.
- [ ] A short `CHANGELOG.md` entry naming the phase.
